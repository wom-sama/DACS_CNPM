# Remaining Error External Support Diagnostic

Validation-only diagnostic; do not use as a deployment router or test tuner.

- Base CSV: `runs\eval_patch_linear_verifier_softboost001_full_val_20260705\predictions_detailed.csv`
- Remaining errors CSV: `runs\forensics_softboost_verifier_remaining_errors_20260705\remaining_errors.csv`
- External predictors: aidt, top5, effv2, dino
- Consensus min votes: `2`
