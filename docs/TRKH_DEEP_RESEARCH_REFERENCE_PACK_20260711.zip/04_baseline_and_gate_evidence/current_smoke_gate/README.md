# TRKH Smoke Gate Audit

Smoke-gate audit only. No trainable manifests, relabels, sample weights, targeted margins, soft targets, raw-data edits, test tuning, or training launches.

Smoke gate ready: `false`
Next class-1 milestone: `0.75`
Blocking reasons: `no_fold_safe_manual_or_new_surface_signal_ready, signal_gap_smoke_gate_false, review_readiness_ready_count_zero, all_review_manual_fields_empty, review_blocking_mixed_actionable_clusters_present, rival24_mixed_actionable_cluster_present, external_consensus_class1_below_milestone, external_consensus_true_class1_recall_coverage_insufficient, xai_supports_surface_boundary_not_background_context`

Smoke gate remains closed for automatic TRKH training from the current artifacts.
