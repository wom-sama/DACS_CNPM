# Boundary Review Manifest

- Predictions: `runs\eval_full_v8_yolof_pairroute_tfb015_30eautorun_best_softboost001_full_val_20260711\predictions_detailed.csv`
- Split: `val`
- Selected rows: `48`

Use `boundary_review_manifest.csv` to label boundary cases manually:

- `manual_label_status`: `correct`, `ambiguous`, `wrong`, `needs_crop`.
- `quality_lighting`: note over-bright, under-dark, glare, shadow.
- `quality_dirty_obstacle`: note dirt, obstacle, occlusion.
- `quality_partial_fruit`: note partial fruit or object cut off.
- `quality_background_mask`: note whether background/mask is acceptable.

Do not use validation/test labels to tune train-time sample weights directly.
