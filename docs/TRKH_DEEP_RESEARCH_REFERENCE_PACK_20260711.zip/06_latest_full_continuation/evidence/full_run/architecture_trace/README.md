# TRKH 5-Class Architecture Trace

Moi thu muc class chua mot anh train ngau nhien co seed co dinh va cac anh trung gian.
Trace dung checkpoint da train: `D:\DataAI\AIEx\TRKH\runs\full_v8_yolof_pairroute_teacherfocusbinary015_boundarydrop_bboxprior_30e_autorun_20260711\checkpoints\best.pt`.

- `00_original.jpg`: anh crop goc.
- `01a_resized_before_preprocess.png`: anh sau resize-pad, truoc normalization/loc nen.
- `01b_illumination_normalized.png`: anh sau chuan hoa sang/toi.
- `01c_foreground_mask_overlay.png`: vung xanh la pseudo foreground duoc giu.
- `01d_surface_detail_mask_overlay.png`: mask chuyen dung cho surface-detail amplification.
- `01e_surface_detail_amplified.png`: anh sau khuech dai residual/high-frequency foreground.
- `01_model_input.png`: anh sau resize-pad va denormalize de xem.
- `02_stem_activation.png`: mean absolute activation cua CNN stem.
- `03_patch_embedding_norm.png`: norm patch token truoc transformer.
- `03b_shifted_patch_residual_norm.png`: norm residual SPT bon huong tai patch embedding.
- `04_detail_map.png`: local color/high-frequency/edge map.
- `05_foreground_prior.png`: prior dung cung attention khi xep hang token.
- `06_attention_view_score.png`: score source theo train config ket hop foreground prior.
- `07_attention_crop.png`: crop salient dung lam view phu khi train.
- `07b_relative_position_layer_XX_center.png`: GPSA-style positional map tu patch gan tam theo tung layer.
- `08_attention_drop.png`: vung salient bi blur de ep model tim dau hieu phu.
- `09a_foreground_surface_weight.png`: mask mem foreground-only cua surface fusion head.
- `09b_foreground_surface_mask.png`: mask cung dung de cat nen cho audit map.
- `09c_foreground_surface_edge_detail.png`: chi tiet cuc bo/edge sau khi mask foreground.
- `09d_foreground_surface_dark_spot.png`: diem vet toi/underexposure/bam sau khi mask foreground.
- `09e_foreground_surface_brown_spot.png`: diem vet nau/hu hong sau khi mask foreground.
- `09f_foreground_surface_bright_spot.png`: diem qua sang/lo sang sau khi mask foreground.
- `09g_bilinear_patch_attention.png`: trong so patch cua compact bilinear fusion sau pruning.
- `09h_frequency_selective_votes.png`: ty le vote patch cua frequency-selective aggregation sau pruning.
- `09i_micro_detail_attention.png`: top-K patch chi tiet foreground cua micro-detail expert.
- `09i1`/`09i2`: attention va probability cua patch-objectness head hoc tu bbox prior.
- `09i3`/`09i4`: object/background patch pooling co dinh theo bbox prior.
- `09q_part_token_attention_mean.png` / `09q_part_token_XX_attention.png`: attention cua learned part-token tren patch foreground/bbox.
- `09r_part_token_pairwise_attention_mean.png` / `09r_part_token_pairwise_XX_attention.png`: attention cua part-token pairwise margin head.
- `09j_local_zoom_score.png` / `09k_local_zoom_crop_box.png`: score map va vung crop cua local-zoom expert.
- `09l`-`09p`: ban do high-pass/gradient/laplacian va foreground-detail cua high-frequency texture expert.
- `09s`-`09z`: bbox/foreground/interior-boundary mask/weight va boundary edge/brown maps cua pairwise head moi.
- `multi_granularity_*` trong `shapes.json`: logits phu o cac transformer layer trung gian.
- `pairwise_margin_route_weights` trong `shapes.json`: trong so router cho tung pairwise specialist.
- `cumulative_ordinal_logits` trong `shapes.json`: threshold logits cho cac bien ordinal 0|1, 1|2, 2|3.
- `block_XX_token_norm.png`: norm token sau tung transformer block; o da prune de trong.
- `prune_XX_after_layer_Y.png`: patch xanh duoc giu, patch toi bi loai.
- `shapes.json`: shape va patch index chi tiet.

Dataset: `D:\DataAI\AIEx\newdataset\yolo_f\data.yaml`
Seed: `42`
