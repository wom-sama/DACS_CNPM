# Full V8 Continuation Rejection Evidence

This compact root preserves the reportable evidence from the launcher-fixed
continuation of the current no-pretrain V8 keeper recipe. It intentionally
excludes checkpoints, redundant plots, and unselected XAI renders.

## Result

- Run: `full_v8_yolof_pairroute_teacherfocusbinary015_boundarydrop_bboxprior_30e_autorun_20260711`
- Data used for selection: full `yolo_f/val=2606`; test was not opened.
- Early stop: epoch 5; selected epoch 2.
- Raw validation macro/class1 F1: `0.886808/0.681690`.
- Raw class1 precision/recall: `0.593137/0.801324`.
- Frozen softboost validation macro/class1 F1: `0.877042/0.637288`.
- Frozen softboost class1 precision/recall: `0.652778/0.622517`.

The raw continuation increased class1 recall at the cost of precision and did
not beat the keeper's class1 F1 `0.686047`. The existing verifier then removed
too many true class1 predictions. This checkpoint is rejected and must not be
used to open or tune against test.

## XAI Conclusion

The 12 locked validation cases remained object-color sensitive (`8/12`). Mean
object-desaturation prediction drop was `0.15491`, versus background blur/gray
`0.02342/0.02601`. Grad-CAM and rollout still exposed local stem, endpoint,
branch, padding, and border dependence. The continuation did not create a new
interior-surface cue.

## Preserved Files

- `full_run`: config, launcher record, history, selected metrics, architecture
  trace summary, per-class shapes, and representative class1 trace maps.
- `softboost_eval`: full-validation metrics and row predictions.
- `boundary_review`: balanced 48-row review and locked XAI selection.
- `xai`: full JSON/CSV/Markdown audit, transition contact sheet, and three
  representative visual case groups.

Raw datasets were not modified. No trainable manifest or test result was
created by this experiment.
