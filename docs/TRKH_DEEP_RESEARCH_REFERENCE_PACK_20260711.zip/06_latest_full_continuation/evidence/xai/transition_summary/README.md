# XAI Transition Summary

Source: `runs\xai_full_v8_yolof_tfb015_30eautorun_best_softboost001_val_cases12_20260711\xai_audit_summary.json`

This artifact summarizes existing XAI cases by target->prediction transition.
It is diagnostic-only and must not be used as a trainable manifest.

Cases: `12`
Transitions: `7`
