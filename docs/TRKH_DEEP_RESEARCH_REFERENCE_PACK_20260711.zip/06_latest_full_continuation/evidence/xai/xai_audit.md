# XAI audit

- Checkpoint: `runs\full_v8_yolof_pairroute_teacherfocusbinary015_boundarydrop_bboxprior_30e_autorun_20260711\checkpoints\best.pt`
- Data: `D:\DataAI\AIEx\newdataset\yolo_f\data.yaml`
- Split: `val`
- Selected cases: `12`
- Patch-evidence linear verifier: `runs\patch_evidence_mil_yolof_keeper_01only_exportparams_20260705\pair_verifier_model_params.json` pair `[0, 1]` feature_dim `318`

## Top confusion pairs

| True | Pred | Count |
|---:|---:|---:|
| 3 | 2 | 47 |
| 1 | 0 | 41 |
| 0 | 1 | 26 |
| 4 | 0 | 13 |
| 4 | 1 | 12 |
| 0 | 4 | 10 |
| 1 | 2 | 10 |
| 2 | 1 | 8 |
| 2 | 0 | 7 |
| 2 | 4 | 7 |

## Heatmap Focus Summary

| Method | Foreground mass | Background mass | Border mass | Entropy |
|---|---:|---:|---:|---:|
| attention | 0.9232 | 0.0768 | 0.0977 | 0.8975 |
| grad_rollout | 0.8837 | 0.1163 | 0.1853 | 0.9475 |
| gradcam | 0.7260 | 0.2740 | 0.2740 | 0.8862 |
| rollout | 0.8417 | 0.1583 | 0.2659 | 0.9848 |

## Review Flags

| Flag | Count |
|---|---:|
| attention_background_attention | 4 |
| attention_border_attention | 1 |
| background_blur_shortcut_sensitive | 1 |
| background_gray_shortcut_sensitive | 1 |
| grad_rollout_background_attention | 5 |
| grad_rollout_border_attention | 3 |
| gradcam_background_attention | 5 |
| gradcam_border_attention | 6 |
| near_tie_top2 | 4 |
| object_color_sensitive | 8 |
| rollout_background_attention | 9 |
| rollout_border_attention | 7 |

## Robustness Probe Summary

| Probe | Pred prob drop | Target prob drop |
|---|---:|---:|
| background_blur | 0.0234 | -0.0236 |
| background_gray | 0.0260 | -0.0253 |
| center_occlusion | 0.0657 | -0.0561 |
| clean_recheck | 0.0000 | 0.0000 |
| object_desaturate | 0.1549 | -0.0055 |

## Register Diagnostics

| Metric | Mean |
|---|---:|
| cls_attention_entropy | 0.8312 |
| cls_register_heatmap_similarity | 0.9999 |
| cls_to_patch_attention_mean | 0.0036 |
| register_attention_entropy | 0.8295 |
| register_to_cls_attention_mean | 0.0142 |
| register_to_patch_attention_mean | 0.0036 |
| register_to_register_attention_mean | 0.0137 |

## Selected cases

| Case | Reason | True | Pred | Conf | Margin |
|---|---|---|---|---:|---:|
| `case_001_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.3994 | 0.2225 |
| `case_002_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.3709 | 0.1981 |
| `case_003_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.3642 | 0.1902 |
| `case_004_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.3608 | 0.1751 |
| `case_005_t3_p1_explicit_sample_index` | explicit_sample_index | Xoai_ChinGia_NgotGat_KhongVanChuyen | Xoai_Song_ChuaNhe_CoNguyCo | 0.3896 | 0.2190 |
| `case_006_t4_p1_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Song_ChuaNhe_CoNguyCo | 0.3874 | 0.2048 |
| `case_007_t2_p1_explicit_sample_index` | explicit_sample_index | Xoai_Chin_NgotThanh_DeDap | Xoai_Song_ChuaNhe_CoNguyCo | 0.3338 | 0.1225 |
| `case_008_t4_p1_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Song_ChuaNhe_CoNguyCo | 0.3236 | 0.1311 |
| `case_009_t3_p2_explicit_sample_index` | explicit_sample_index | Xoai_ChinGia_NgotGat_KhongVanChuyen | Xoai_Chin_NgotThanh_DeDap | 0.2346 | 0.0009 |
| `case_010_t2_p3_explicit_sample_index` | explicit_sample_index | Xoai_Chin_NgotThanh_DeDap | Xoai_ChinGia_NgotGat_KhongVanChuyen | 0.2683 | 0.0021 |
| `case_011_t2_p0_explicit_sample_index` | explicit_sample_index | Xoai_Chin_NgotThanh_DeDap | Xoai_Song_Chua_KhoDap | 0.2276 | 0.0031 |
| `case_012_t3_p2_explicit_sample_index` | explicit_sample_index | Xoai_ChinGia_NgotGat_KhongVanChuyen | Xoai_Chin_NgotThanh_DeDap | 0.2751 | 0.0095 |
