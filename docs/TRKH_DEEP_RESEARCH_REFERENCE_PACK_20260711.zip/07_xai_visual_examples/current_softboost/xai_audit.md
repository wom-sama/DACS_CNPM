# XAI audit

- Checkpoint: `runs\probe_v8_yolof_pairroute_teacherfocusbinary015_boundarydrop_bboxprior_120b_2e_20260701\checkpoints\best.pt`
- Data: `D:\DataAI\AIEx\newdataset\yolo_f\data.yaml`
- Split: `val`
- Selected cases: `16`
- Patch-evidence linear verifier: `runs\patch_evidence_mil_yolof_keeper_01only_exportparams_20260705\pair_verifier_model_params.json` pair `[0, 1]` feature_dim `318`

## Top confusion pairs

| True | Pred | Count |
|---:|---:|---:|
| 3 | 2 | 52 |
| 0 | 1 | 41 |
| 1 | 0 | 19 |
| 4 | 0 | 12 |
| 0 | 4 | 11 |
| 1 | 2 | 11 |
| 2 | 1 | 9 |
| 2 | 3 | 9 |
| 4 | 1 | 8 |
| 2 | 0 | 6 |

## Heatmap Focus Summary

| Method | Foreground mass | Background mass | Border mass | Entropy |
|---|---:|---:|---:|---:|
| attention | 0.8711 | 0.1289 | 0.1668 | 0.8585 |
| grad_rollout | 0.9555 | 0.0445 | 0.1606 | 0.9473 |
| gradcam | 0.8362 | 0.1638 | 0.2329 | 0.8933 |
| rollout | 0.8946 | 0.1054 | 0.2662 | 0.9854 |

## Review Flags

| Flag | Count |
|---|---:|
| attention_background_attention | 6 |
| attention_border_attention | 5 |
| grad_rollout_border_attention | 2 |
| gradcam_background_attention | 5 |
| gradcam_border_attention | 8 |
| near_tie_top2 | 13 |
| rollout_background_attention | 7 |
| rollout_border_attention | 10 |

## Robustness Probe Summary

| Probe | Pred prob drop | Target prob drop |
|---|---:|---:|
| background_blur | 0.0035 | -0.0027 |
| background_gray | -0.0038 | -0.0006 |
| center_occlusion | 0.0122 | -0.0097 |
| clean_recheck | 0.0000 | 0.0000 |
| object_desaturate | 0.0627 | 0.0205 |

## Register Diagnostics

| Metric | Mean |
|---|---:|
| cls_attention_entropy | 0.8119 |
| cls_register_heatmap_similarity | 0.9999 |
| cls_to_patch_attention_mean | 0.0037 |
| register_attention_entropy | 0.8101 |
| register_to_cls_attention_mean | 0.0095 |
| register_to_patch_attention_mean | 0.0037 |
| register_to_register_attention_mean | 0.0096 |

## Selected cases

| Case | Reason | True | Pred | Conf | Margin |
|---|---|---|---|---:|---:|
| `case_001_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.2545 | 0.0385 |
| `case_002_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.2232 | 0.0017 |
| `case_003_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.2324 | 0.0054 |
| `case_004_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.2300 | 0.0058 |
| `case_005_t4_p4_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Hu_KhongAnDuoc | 0.2524 | 0.0029 |
| `case_006_t0_p1_explicit_sample_index` | explicit_sample_index | Xoai_Song_Chua_KhoDap | Xoai_Song_ChuaNhe_CoNguyCo | 0.2700 | 0.0063 |
| `case_007_t2_p1_explicit_sample_index` | explicit_sample_index | Xoai_Chin_NgotThanh_DeDap | Xoai_Song_ChuaNhe_CoNguyCo | 0.2625 | 0.0091 |
| `case_008_t0_p1_explicit_sample_index` | explicit_sample_index | Xoai_Song_Chua_KhoDap | Xoai_Song_ChuaNhe_CoNguyCo | 0.2684 | 0.0182 |
| `case_009_t3_p2_explicit_sample_index` | explicit_sample_index | Xoai_ChinGia_NgotGat_KhongVanChuyen | Xoai_Chin_NgotThanh_DeDap | 0.2658 | 0.0010 |
| `case_010_t3_p2_explicit_sample_index` | explicit_sample_index | Xoai_ChinGia_NgotGat_KhongVanChuyen | Xoai_Chin_NgotThanh_DeDap | 0.2415 | 0.0065 |
| `case_011_t3_p2_explicit_sample_index` | explicit_sample_index | Xoai_ChinGia_NgotGat_KhongVanChuyen | Xoai_Chin_NgotThanh_DeDap | 0.2407 | 0.0074 |
| `case_012_t3_p2_explicit_sample_index` | explicit_sample_index | Xoai_ChinGia_NgotGat_KhongVanChuyen | Xoai_Chin_NgotThanh_DeDap | 0.2510 | 0.0077 |
| `case_013_t4_p0_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Song_Chua_KhoDap | 0.2520 | 0.0143 |
| `case_014_t4_p0_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Song_Chua_KhoDap | 0.2378 | 0.0170 |
| `case_015_t4_p0_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Song_Chua_KhoDap | 0.2450 | 0.0211 |
| `case_016_t4_p0_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Song_Chua_KhoDap | 0.2571 | 0.0235 |
