# Shifted Patch Tokenization Rejected Evidence

This compact evidence root preserves the three SPT smoke schedules, the valid
full-validation verifier output, balanced boundary review, XAI summaries, five
SPT residual heatmaps, and two representative visual cases.

The effective fixed-horizon smoke reached validation macro/class-1 F1
`0.8830/0.6822`, below keeper `0.8847/0.6860`. The current runtime verifier
reduced it to `0.8772/0.6502`. No test split or raw-data edit was used.

Original checkpoint, plot, and rendered case payloads were deleted only after
the JSON/CSV/TXT/MD evidence and selected images were verified here.
