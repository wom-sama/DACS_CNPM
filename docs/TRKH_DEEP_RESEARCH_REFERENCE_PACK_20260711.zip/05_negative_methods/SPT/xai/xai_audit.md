# XAI audit

- Checkpoint: `runs\smoke_v8_yolof_spt_shift1_scale010_lr1e4_sched10fixed_60b_1e_20260711\checkpoints\best.pt`
- Data: `D:\DataAI\AIEx\newdataset\yolo_f\data.yaml`
- Split: `val`
- Selected cases: `12`
- Patch-evidence linear verifier: `runs\patch_evidence_mil_yolof_keeper_01only_exportparams_20260705\pair_verifier_model_params.json` pair `[0, 1]` feature_dim `318`

## Top confusion pairs

| True | Pred | Count |
|---:|---:|---:|
| 3 | 2 | 52 |
| 1 | 0 | 43 |
| 0 | 1 | 21 |
| 4 | 0 | 12 |
| 0 | 4 | 11 |
| 1 | 2 | 11 |
| 2 | 3 | 9 |
| 2 | 0 | 8 |
| 4 | 1 | 8 |
| 2 | 1 | 7 |

## Heatmap Focus Summary

| Method | Foreground mass | Background mass | Border mass | Entropy |
|---|---:|---:|---:|---:|
| attention | 0.9462 | 0.0538 | 0.1503 | 0.8776 |
| grad_rollout | 0.8979 | 0.1021 | 0.1867 | 0.9504 |
| gradcam | 0.7713 | 0.2287 | 0.2218 | 0.8753 |
| rollout | 0.8476 | 0.1524 | 0.2585 | 0.9847 |

## Review Flags

| Flag | Count |
|---|---:|
| attention_border_attention | 1 |
| gradcam_background_attention | 3 |
| gradcam_border_attention | 3 |
| near_tie_top2 | 4 |
| object_color_sensitive | 8 |

## Robustness Probe Summary

| Probe | Pred prob drop | Target prob drop |
|---|---:|---:|
| background_blur | 0.0115 | -0.0061 |
| background_gray | 0.0125 | -0.0048 |
| center_occlusion | 0.0671 | -0.0461 |
| clean_recheck | 0.0000 | 0.0000 |
| object_desaturate | 0.1259 | -0.0049 |

## Register Diagnostics

| Metric | Mean |
|---|---:|
| cls_attention_entropy | 0.8320 |
| cls_register_heatmap_similarity | 0.9998 |
| cls_to_patch_attention_mean | 0.0036 |
| register_attention_entropy | 0.8314 |
| register_to_cls_attention_mean | 0.0134 |
| register_to_patch_attention_mean | 0.0036 |
| register_to_register_attention_mean | 0.0131 |

## Selected cases

| Case | Reason | True | Pred | Conf | Margin |
|---|---|---|---|---:|---:|
| `case_001_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.3795 | 0.2030 |
| `case_002_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.3668 | 0.1975 |
| `case_003_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.3541 | 0.1898 |
| `case_004_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.3445 | 0.1590 |
| `case_005_t3_p1_explicit_sample_index` | explicit_sample_index | Xoai_ChinGia_NgotGat_KhongVanChuyen | Xoai_Song_ChuaNhe_CoNguyCo | 0.3800 | 0.2060 |
| `case_006_t4_p1_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Song_ChuaNhe_CoNguyCo | 0.3442 | 0.1280 |
| `case_007_t2_p1_explicit_sample_index` | explicit_sample_index | Xoai_Chin_NgotThanh_DeDap | Xoai_Song_ChuaNhe_CoNguyCo | 0.3213 | 0.1106 |
| `case_008_t4_p1_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Song_ChuaNhe_CoNguyCo | 0.3124 | 0.1055 |
| `case_009_t2_p0_explicit_sample_index` | explicit_sample_index | Xoai_Chin_NgotThanh_DeDap | Xoai_Song_Chua_KhoDap | 0.2614 | 0.0000 |
| `case_010_t3_p2_explicit_sample_index` | explicit_sample_index | Xoai_ChinGia_NgotGat_KhongVanChuyen | Xoai_Chin_NgotThanh_DeDap | 0.2660 | 0.0010 |
| `case_011_t2_p4_explicit_sample_index` | explicit_sample_index | Xoai_Chin_NgotThanh_DeDap | Xoai_Hu_KhongAnDuoc | 0.2903 | 0.0023 |
| `case_012_t4_p2_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Chin_NgotThanh_DeDap | 0.2387 | 0.0019 |
