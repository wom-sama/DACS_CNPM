# XAI audit

- Checkpoint: `runs\smoke_v8_yolof_gpsa_relpos1234_emafixste_max025_lr3e4_sched10_60b_1e_20260711\checkpoints\best.pt`
- Data: `D:\DataAI\AIEx\newdataset\yolo_f\data.yaml`
- Split: `val`
- Selected cases: `12`
- Patch-evidence linear verifier: `runs\patch_evidence_mil_yolof_keeper_01only_exportparams_20260705\pair_verifier_model_params.json` pair `[0, 1]` feature_dim `318`

## Top confusion pairs

| True | Pred | Count |
|---:|---:|---:|
| 3 | 2 | 45 |
| 1 | 0 | 38 |
| 0 | 1 | 26 |
| 1 | 2 | 19 |
| 0 | 4 | 15 |
| 4 | 0 | 10 |
| 2 | 3 | 9 |
| 4 | 1 | 8 |
| 1 | 4 | 7 |
| 2 | 4 | 7 |

## Heatmap Focus Summary

| Method | Foreground mass | Background mass | Border mass | Entropy |
|---|---:|---:|---:|---:|
| attention | 0.8965 | 0.1035 | 0.1487 | 0.8749 |
| grad_rollout | 0.9221 | 0.0779 | 0.1560 | 0.9424 |
| gradcam | 0.7008 | 0.2992 | 0.3536 | 0.9081 |
| rollout | 0.8760 | 0.1240 | 0.2649 | 0.9843 |

## Review Flags

| Flag | Count |
|---|---:|
| attention_background_attention | 3 |
| attention_border_attention | 3 |
| grad_rollout_background_attention | 3 |
| grad_rollout_border_attention | 1 |
| gradcam_background_attention | 7 |
| gradcam_border_attention | 9 |
| near_tie_top2 | 4 |
| object_color_sensitive | 6 |
| rollout_background_attention | 7 |
| rollout_border_attention | 7 |

## Robustness Probe Summary

| Probe | Pred prob drop | Target prob drop |
|---|---:|---:|
| background_blur | 0.0154 | -0.0033 |
| background_gray | 0.0154 | -0.0041 |
| center_occlusion | 0.0658 | -0.0407 |
| clean_recheck | 0.0000 | 0.0000 |
| object_desaturate | 0.1475 | -0.0144 |

## Register Diagnostics

| Metric | Mean |
|---|---:|
| cls_attention_entropy | 0.8210 |
| cls_register_heatmap_similarity | 0.9998 |
| cls_to_patch_attention_mean | 0.0036 |
| register_attention_entropy | 0.8197 |
| register_to_cls_attention_mean | 0.0149 |
| register_to_patch_attention_mean | 0.0036 |
| register_to_register_attention_mean | 0.0143 |

## Selected cases

| Case | Reason | True | Pred | Conf | Margin |
|---|---|---|---|---:|---:|
| `case_001_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.3653 | 0.1873 |
| `case_002_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.3449 | 0.1684 |
| `case_003_t1_p0_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Song_Chua_KhoDap | 0.3397 | 0.1517 |
| `case_004_t1_p2_explicit_sample_index` | explicit_sample_index | Xoai_Song_ChuaNhe_CoNguyCo | Xoai_Chin_NgotThanh_DeDap | 0.3336 | 0.1567 |
| `case_005_t0_p1_explicit_sample_index` | explicit_sample_index | Xoai_Song_Chua_KhoDap | Xoai_Song_ChuaNhe_CoNguyCo | 0.4146 | 0.2597 |
| `case_006_t3_p1_explicit_sample_index` | explicit_sample_index | Xoai_ChinGia_NgotGat_KhongVanChuyen | Xoai_Song_ChuaNhe_CoNguyCo | 0.3828 | 0.2041 |
| `case_007_t4_p1_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Song_ChuaNhe_CoNguyCo | 0.3418 | 0.1237 |
| `case_008_t4_p1_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Song_ChuaNhe_CoNguyCo | 0.3115 | 0.0982 |
| `case_009_t3_p2_explicit_sample_index` | explicit_sample_index | Xoai_ChinGia_NgotGat_KhongVanChuyen | Xoai_Chin_NgotThanh_DeDap | 0.2658 | 0.0031 |
| `case_010_t3_p2_explicit_sample_index` | explicit_sample_index | Xoai_ChinGia_NgotGat_KhongVanChuyen | Xoai_Chin_NgotThanh_DeDap | 0.2466 | 0.0033 |
| `case_011_t4_p0_explicit_sample_index` | explicit_sample_index | Xoai_Hu_KhongAnDuoc | Xoai_Song_Chua_KhoDap | 0.2330 | 0.0041 |
| `case_012_t2_p0_explicit_sample_index` | explicit_sample_index | Xoai_Chin_NgotThanh_DeDap | Xoai_Song_Chua_KhoDap | 0.2660 | 0.0051 |
