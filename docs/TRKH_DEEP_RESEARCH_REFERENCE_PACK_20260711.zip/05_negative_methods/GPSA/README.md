# GPSA Relative-Position Adapter Rejection Evidence

This compact root preserves the validation-only evidence used to reject the
GPSA-style gated relative-position attention adapter on 2026-07-11. Raw
`class_f` and `yolo_f` data were not modified, and the test split was not used.

## Decision

- Keeper reference: macro/class1 F1 `0.8847/0.6860`.
- Current keeper plus runtime softboost: `0.8887/0.7030`.
- Valid GPSA EMA smoke: `0.87895/0.65455`, class1 P/R
  `0.60335/0.71523`.
- GPSA raw train state: `0.87503/0.65193`.
- GPSA EMA plus runtime softboost: `0.87113/0.61702`, class1 recall
  `0.57616`.

The learned EMA gates remained close to zero and XAI showed no new transferable
surface cue. Do not sweep nearby LR, max mix, layers, batches, epochs, or head
freezing on this keeper. The implementation remains default-off for a future
from-scratch ablation.

## Infrastructure Note

The smoke without `emafixste` is not valid representation evidence. It exposed
two training issues subsequently fixed and covered by tests: partial
architecture extensions must reset the mature keeper EMA update counter, and
bounded gates need a straight-through projected clamp during training to avoid
zero-gradient dead heads.

## Preserved Material

The subdirectories retain smoke metrics/config/history/transcripts, raw and
runtime-verifier full-validation predictions, gate trace summaries and center
maps, the balanced boundary manifest, XAI summaries/transition table/contact
sheet, and three representative crop/attention/Grad-CAM/rollout groups. Heavy
checkpoints and redundant plots were intentionally omitted.
