# Locality Self-Attention Pre-Smoke Probe

- Split/support: `val` / `2606`
- Layers: `1,2,3,4`
- Prefix tokens preserved: `7`
- Test accessed: `False`
- Smoke gate ready: `False`
- Candidate variants: `[]`

The transform preserves prefix query rows, patch-to-prefix links, and each patch row's total patch mass. It writes no trainable parameters, manifests, or raw-data changes.
