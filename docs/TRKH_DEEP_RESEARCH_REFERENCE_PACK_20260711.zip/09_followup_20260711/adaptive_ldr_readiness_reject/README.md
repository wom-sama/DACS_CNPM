# Adaptive LDR readiness

This no-test diagnostic reproduces the official one-step ALDR lambda update from aligned probabilities and measures error ranking, class-1 FN/FP ordering, lambda spread, and the resulting target-gradient change. It writes no training manifest and does not modify data.
