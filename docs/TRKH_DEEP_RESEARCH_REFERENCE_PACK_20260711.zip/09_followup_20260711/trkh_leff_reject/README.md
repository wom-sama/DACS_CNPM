# TRKH Concurrent LeFF Rejection Evidence

## Scope

- Architecture change: replace the token-wise feed-forward network in TRKH
  transformer layers 1-4 with a true locally enhanced feed-forward network
  (LeFF): linear expansion, GELU/dropout, hidden-channel depthwise 3x3
  convolution plus BatchNorm/GELU on the spatial patch grid, then linear
  projection. CLS/register/branch prefix tokens bypass the spatial convolution.
- Dense and token-pruned grids are supported through deterministic
  scatter/convolve/gather using `patch_indices`.
- The feature is default-off and the legacy checkpoint schema remains unchanged
  when disabled.
- Data: immutable `yolo_f`, image 256, batch 32, accumulation 2, strict balanced
  sampling, 120 train batches per epoch, and full validation (2,606 objects).
- Training: from scratch, LDAM-focal, EMA 0.995, teacher-focus-binary 0.015,
  metric learning, bbox prior, pairwise routing, boundary dropout, scheduler
  horizon 15, and no test evaluation.

## Research Basis

- LocalViT (arXiv 2104.05707) motivates adding locality inside the transformer
  feed-forward path.
- CeiT/LeFF (arXiv 2103.11816) replaces the token-wise FFN with a locally
  enhanced alternative and reports faster convergence.
- CvT (arXiv 2103.15808) supports convolutional inductive bias inside a
  transformer hierarchy.
- This experiment is distinct from the earlier zero-initialized external
  block-local adapter: LeFF is concurrent inside the FFN and trained from
  initialization.

## Verification And Resource Gate

- Focused LeFF/block-mixer/DAC tests passed `13/13`; Python compilation,
  PowerShell parse, dry-run, config reconstruction, pruned-token gradients, and
  checkpoint round-trip passed.
- Parameter count: `7,290,646` versus legacy `7,245,590` (`+45,056`, about
  `+0.62%`).
- Synthetic BF16 batch-32 throughput: `206.92 img/s` versus legacy
  `222.09 img/s`; peak allocation/reserve was `2.756/3.389 GB` versus
  `2.533/3.264 GB`.
- The real five-epoch probe peaked at `4.734/5.594 GB` allocated/reserved and
  completed in `654.5 s`; test summary remained null.

## Smoke Gate

- A 20-batch, one-epoch smoke reached validation macro/class-1 F1
  `0.54277/0.26479`. It was used only as a pipeline and gradient gate.
- Twelve-case XAI foreground mass was attention/grad-rollout/Grad-CAM/rollout
  `0.9540/0.9447/0.9597/0.9487`.
- Background blur/gray prediction drops were `-0.0031/0.0028`, while object
  desaturation was `0.2176`; the model was causally object-focused and earned
  the fixed five-epoch probe.

## Five-Epoch Result

| Epoch | Val macro F1 | Class-1 P | Class-1 R | Class-1 F1 |
|---:|---:|---:|---:|---:|
| 1 | 0.734145 | 0.300448 | 0.443709 | 0.358289 |
| 2 | 0.754458 | 0.311828 | 0.576159 | 0.404651 |
| 3 | 0.784473 | 0.376518 | 0.615894 | 0.467337 |
| 4 | 0.784842 | 0.353147 | 0.668874 | 0.462243 |
| 5, selected | 0.791697 | 0.363958 | 0.682119 | 0.474654 |

Independent reload exactly reproduced accuracy/macro/class-1 F1
`0.839601/0.791697/0.474654`. Its confusion matrix was:

```text
[[485, 62,  2,  0,  0],
 [ 35,103, 13,  0,  0],
 [  1, 42,454, 43,  4],
 [  0,  4, 84,622,  2],
 [ 32, 72, 14,  8,524]]
```

Class 1 had 103 TP, 180 FP, and 48 FN. The boundary audit found 784
candidates, worse than stage-wise MBConv (709) and stock CoAtNet-Nano epoch 5
(584). The result is also below stage-wise MBConv macro/class-1
`0.7973/0.5050`, CoAtNet-Nano `0.8303/0.5534`, and the current raw keeper
`0.8847/0.6860`.

## Final XAI

- Attention/grad-rollout/Grad-CAM/rollout foreground mass was
  `0.9640/0.9379/0.8347/0.8658`.
- Background blur/gray prediction drops were only `0.0060/0.0072`; center
  occlusion was `0.0153` and object desaturation was `0.1262`.
- Direct review of `4->1`, `0->1`, `1->2`, and `1->0` overlays showed focus on
  fruit color, spots, wrinkles, contour, and stem/edge regions. The model did
  not fail because of wide-background dependence; it learned a class-unsafe
  maturity/surface boundary and over-predicted class 1.

## Decision

Reject this exact layers-1-4, kernel-3 concurrent LeFF recipe at the fixed
five-epoch fast-convergence gate. Do not continue it to 10/15/30 epochs or
sweep nearby layer subsets, kernel sizes, width, LR, loss, sampler, teacher, or
normalization settings. Keep the default-off implementation for reproducible
architecture ablation, but do not replace the current keeper or open test.

## Contents

- `source_smoke_20b`: smoke config, metrics, trace, curves, and launcher record.
- `xai_smoke_20b`: smoke heatmaps and robustness audit.
- `source_probe_5e`: probe config, complete history, metrics, trace, and curves.
- `eval_best`: independent full-validation predictions and metrics.
- `boundary_best`: leakage-guarded validation boundary review manifest.
- `xai_best`: final heatmaps, case metadata, and robustness audit.

No checkpoint, raw dataset file, or test output is retained in this package.
