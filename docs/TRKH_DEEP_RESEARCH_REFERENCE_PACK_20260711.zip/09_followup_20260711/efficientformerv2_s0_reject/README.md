# EfficientFormerV2-S0 Scratch Rejection Evidence

## Scope

- Architecture: `timm efficientformerv2_s0`, 3,248,026 parameters, initialized
  from scratch.
- Mechanism: early local convolutional blocks followed by EfficientFormerV2
  multi-scale attention blocks.
- Data: immutable `yolo_f`, object-crop classification path, native image size
  224. The model's fixed attention grid is incompatible with the 256-pixel
  launcher setting, so 224 is the only valid size for this audit.
- Training: strict balanced sampler, LDAM-focal, EMA 0.995,
  teacher-focus-binary 0.015, 120 train batches per epoch, five epochs, and a
  cosine scheduler horizon of 15 epochs.
- Leakage guard: full validation only. `test_summary` is null and no test
  prediction or metric is included.

## Fixed Gate

The gate was declared before training: at epoch 5 the candidate had to match
both CoAtNet-Nano's validation macro F1 `0.830315` and class-1 F1 `0.553398`.
Failure closes the route without nearby image-size, learning-rate, loss,
sampler, teacher, or epoch sweeps.

## Result

| Checkpoint | Val macro F1 | Class-1 P | Class-1 R | Class-1 F1 |
|---|---:|---:|---:|---:|
| Epoch 3, selector checkpoint | 0.798224 | 0.386986 | 0.748344 | 0.510158 |
| Epoch 4, highest raw macro | 0.808905 | 0.391003 | 0.748344 | 0.513636 |
| Epoch 5 | 0.807672 | 0.374172 | 0.748344 | 0.498896 |
| Epoch 3, independent reload | 0.799147 | 0.386986 | 0.748344 | 0.510158 |
| CoAtNet-Nano epoch-5 gate | 0.830315 | 0.436782 | 0.754967 | 0.553398 |
| Current TRKH raw keeper | 0.884675 | - | - | 0.686047 |

The fair selector retained epoch 3 even though epoch 4 had the highest raw
macro F1. Independent reload of `best.pt` produced this confusion matrix:

```text
[[455, 74,  2,  0, 18],
 [ 27,113,  9,  0,  2],
 [  0, 50,444, 42,  8],
 [  0,  3, 81,627,  1],
 [ 21, 52, 10,  8,559]]
```

Class 1 therefore had 113 true positives, 176 false positives, and 38 false
negatives. The candidate increased recall by widening the class-1 region but
did not learn conservative `0/2/4 -> 1` control.

## Audit

- The independent boundary review found 853 candidates before limits, worse
  than CoAtNet-Nano epoch 5 at 584.
- On the same 12 locked cases used for the one-epoch pipeline smoke, the best
  checkpoint was correct on 3/12.
- Attention and Grad-CAM foreground mass were `0.88101/0.88577`, with border
  mass `0.22061/0.23113`.
- Mean original-prediction drops were `-0.00376` for background blur,
  `-0.00481` for background gray, `0.02055` for center occlusion, and
  `0.12554` for object desaturation.
- Visual review showed activation on fruit color and lesions, but also on
  stems, gloves, padding, and object boundaries. This is not a wide-background
  shortcut; it is class-unsafe surface/boundary discrimination.

## Decision

Reject this EfficientFormerV2-S0 scratch recipe. It is parameter-efficient and
trainable, but it fails both predeclared epoch-5 gates, regresses after epoch 4,
and produces more boundary candidates than CoAtNet-Nano. Do not continue to
10/15/30 epochs or sweep nearby training settings. Keep the architecture only
as compact negative evidence in the stock scratch-hybrid comparison.

## Contents

- `smoke_source` and `smoke_xai`: one-epoch pipeline proof and its mandatory
  12-case audit.
- `probe_source`: five-epoch history, configs, metrics, and execution logs.
- `eval_best`: independent full-validation metrics and row-level predictions.
- `boundary_best`: leakage-guarded validation boundary review.
- `xai_best`: compact same-case XAI summaries and representative overlays.

The rejected checkpoints are intentionally excluded. Source runs may be
deleted only after this directory is hashed and verified.
