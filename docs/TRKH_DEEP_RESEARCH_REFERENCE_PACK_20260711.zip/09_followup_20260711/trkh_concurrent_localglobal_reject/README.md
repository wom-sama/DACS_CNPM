# TRKH Concurrent Local-Global Coupling Rejection Evidence

## Scope

- Architecture change: add a persistent 64-channel local CNN map at the
  16x16 transformer patch grid and couple it bidirectionally with patch tokens
  after transformer layers 1-8.
- Token-to-local uses LayerNorm plus a learned projection and sparse-safe
  scatter. The local state uses a depthwise bottleneck residual update.
  Local-to-token uses a projected map and sparse-safe gather. CLS/register/
  branch prefix tokens are never modified by the coupling module.
- The feature is default-off, preserves the legacy state schema when disabled,
  and supports the existing layer-2/layer-5 token-pruning schedule.
- Data: immutable `yolo_f`, image 256, batch 32, accumulation 2, strict balanced
  sampling, 120 train batches per epoch, and full validation (2,606 objects).
- Training: from scratch, LDAM-focal, EMA 0.995, teacher-focus-binary 0.015,
  metric learning, bbox prior, pairwise routing, boundary dropout, scheduler
  horizon 15, and no test evaluation.

## Research Basis And Distinction

- The official visual Conformer paper/code (arXiv 2105.03889) defines the
  Feature Coupling Unit as interactive CNN-map/Transformer-token exchange while
  retaining concurrent local and global states.
- CMT (arXiv 2107.06263) combines convolutional local modeling with transformer
  long-range dependencies, while CoaT (ICCV 2021, arXiv 2104.06399) preserves
  branch integrity and communicates representations across scales.
- This route is distinct from LeFF, where convolution exists inside an FFN,
  and from the old one-token CNN branch, which discards the spatial map.

## Verification And Resource Gate

- Compile, PowerShell parse/dry-run/preflight, dense/pruned gradients,
  prefix preservation, trace, default schema, and checkpoint round-trip passed;
  the focused LeFF/block-mixer/DAC/coupling suite passed `17/17`.
- Parameters: `7,670,190` versus legacy `7,245,590` (`+5.86%`).
- Synthetic BF16 batch-32 throughput: `198.05 img/s` versus legacy
  `221.13 img/s`; peak allocation/reserve was `2.770/3.480 GB` versus
  `2.501/3.330 GB`.
- Real five-epoch peak allocation/reserve was about `4.808/5.412 GB`; the run
  completed in `672.7 s` and test summary remained null.

## Smoke Gate

- A 20-batch, one-epoch smoke reached macro/class-1 F1
  `0.54089/0.22511`; it was used only as a pipeline/gradient gate.
- Smoke XAI foreground mass was attention/grad-rollout/Grad-CAM/rollout
  `0.8577/0.9445/0.9738/0.9631`. Background blur/gray drops were
  `0.0023/0.0033`, while object desaturation was `0.1815`.
- Coupling telemetry was finite and trainable. Across five traced classes,
  local-state norms rose gradually through the eight blocks and all three
  coupling scales moved away from initialization. The new trace renderer
  stores `03c_concurrent_local_activation.png` plus per-layer norms/scales.

## Five-Epoch Result

| Epoch | Val macro F1 | Class-1 P | Class-1 R | Class-1 F1 |
|---:|---:|---:|---:|---:|
| 1 | 0.739996 | 0.375000 | 0.278146 | 0.319392 |
| 2 | 0.759452 | 0.322464 | 0.589404 | 0.416862 |
| 3 | 0.757210 | 0.311953 | 0.708609 | 0.433198 |
| 4, selected | 0.784535 | 0.341379 | 0.655629 | 0.448980 |
| 5 | 0.787844 | 0.338816 | 0.682119 | 0.452747 |

The fair selector retained epoch 4. Independent reload reproduced
accuracy/macro/class-1 `0.834229/0.784535/0.448980`. Its confusion matrix was:

```text
[[466, 76,  2,  0,  5],
 [ 39, 99, 12,  0,  1],
 [  1, 42,474, 23,  4],
 [  0,  4, 99,601,  8],
 [ 24, 69, 18,  5,534]]
```

Class 1 had 99 TP, 191 FP, and 52 FN. The boundary audit found 802
candidates, worse than LeFF (784), stage-wise MBConv (709), and stock
CoAtNet-Nano epoch 5 (584). The selected result is also below LeFF
`0.79170/0.47465`, stage-wise MBConv `0.79725/0.50495`, CoAtNet-Nano
`0.83032/0.55340`, and the raw keeper `0.88468/0.68605`.

## Final Coupling And XAI Audit

- Coupling did not die: on a traced class-0 sample, local-state norm increased
  `5.648 -> 12.261`, token-residual norm `13.743 -> 16.690`, first/last
  token-to-local scales were `0.4775/0.4982`, and local-to-token scales were
  `0.2605/0.2660` versus initialization `0.25`.
- Final attention/grad-rollout/Grad-CAM/rollout foreground mass was
  `0.9817/0.9401/0.7841/0.8356`. Background blur/gray drops remained only
  `0.0012/0.0009`, while center occlusion was `0.0174` and object
  desaturation `0.1539`.
- Direct local-map and XAI review showed genuine interior coverage plus focus
  on fruit color, spots, wrinkles, contour, and damaged regions. The branch
  learned the intended region but not a class-safe maturity/surface boundary;
  `0/2/4->1` false positives remained dominant.

## Decision

Reject the exact layers-1-8, dim-64, kernel-3 bidirectional coupling recipe at
the five-epoch fast-convergence gate. Do not continue it to 10/15/30 epochs or
sweep nearby layer subsets, local width, kernels, coupling scales, LR, loss,
sampler, teacher, or normalization. Keep the default-off implementation and
trace support for reproducible ablation only; do not replace the keeper or
open test.

## Contents

- `source_smoke_20b`: smoke config, metrics, coupling trace, curves, launcher.
- `xai_smoke_20b`: smoke attribution and robustness evidence.
- `source_probe_5e`: complete probe history, config, metrics, coupling trace.
- `eval_best`: independent full-validation predictions and metrics.
- `boundary_best`: leakage-guarded validation boundary manifest.
- `xai_best`: final heatmaps, cases, and robustness audit.

No checkpoint, raw dataset file, or test output is retained in this package.
