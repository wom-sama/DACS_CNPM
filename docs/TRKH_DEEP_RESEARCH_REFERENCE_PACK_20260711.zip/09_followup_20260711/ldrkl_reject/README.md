# TRKH LDR-KL Stage-2 Smoke Rejection Evidence

## Scope

- Method: Label Distributionally Robust loss with KL regularization (`ldr_kl`).
- Research basis: Zhu et al., *Label Distributionally Robust Losses for
  Multi-class Classification: Consistency, Finite-sample Guarantees, and
  Adaptivity*, ICML 2023. The fixed-loss implementation follows the official
  Apache-2.0 reference formula.
- Configuration: margin `2.0`, temperature `1.0`, keeper checkpoint resume,
  learning rate `8e-5`, 60 train batches, one epoch, image size 256, batch 32,
  accumulation 2, scheduler horizon 15, immutable `yolo_f`, and full validation
  over 2,606 objects.
- Test was not opened and raw data was not changed.

## Implementation Verification

- Added hard/soft-target LDR-KL support, label smoothing, class multipliers,
  per-sample loss, CLI/config plumbing, and a dedicated stage-2 wrapper.
- Python compilation passed.
- Focused robust-loss and LDR-KL tests passed `16/16`.
- Both PowerShell launchers parsed; dry-run and real preflight passed.
- The loss was finite and active throughout training. The model retained
  `7,245,590` parameters and the run completed in about `135 s` internally.

## Validation Result

| Metric | LDR-KL smoke | Raw keeper | Runtime keeper |
|---|---:|---:|---:|
| Macro F1 | 0.880233 | 0.884675 | 0.888675 |
| Class-1 F1 | 0.672515 | 0.686047 | 0.703030 |
| Class-1 precision | 0.602094 | - | - |
| Class-1 recall | 0.761589 | - | - |

The full-validation confusion matrix was:

```text
[[485, 49,  3,  0, 12],
 [ 18,115, 13,  0,  5],
 [  5, 10,514,  8,  7],
 [  0,  3, 53,653,  3],
 [  9, 14,  3,  1,623]]
```

Dominant remaining errors were `3->2=53`, `0->1=49`, `1->0=18`,
`4->1=14`, and `1->2=13`. LDR-KL therefore shifted and amplified the same
unsafe class-1 boundary instead of improving it.

## XAI Audit

- Audited 12 validation cases with attention, gradient rollout, Grad-CAM,
  rollout, and perturbation robustness.
- Foreground mass for attention/gradient-rollout/Grad-CAM/rollout was
  `0.8804/0.9486/0.8438/0.9129`.
- Border mass was `0.1730/0.1595/0.2992/0.2460`.
- Background blur/gray confidence drops were only `0.0133/0.0129`, versus
  center occlusion `0.0499` and object desaturation `0.2058`.
- Nine of 12 cases were object-color sensitive. Visual review confirmed both
  scattered spot fixation on class-1 false negatives and broad lesion/surface
  fixation on false-positive class-1 predictions. Some methods also retained
  substantial border/background activation.

The method attends to real fruit evidence, but it does not acquire a new cue
that separates subtle class 1 from classes 0, 2, and 4.

## Paired-View Precheck

The same keeper checkpoint was evaluated reproducibly on paired `yolo_f` and
`class_f` validation views before attempting cross-view attention:

- `yolo_f`: macro/class-1 F1 `0.884073/0.684058`.
- `class_f`: macro/class-1 F1 `0.880428/0.668605`.
- Only 28 predictions disagreed.
- `class_f` rescued `0/33` `yolo_f` class-1 false negatives and corrected only
  `2/76` class-1 false positives.
- The label-assisted exact oracle was only `0.888270/0.688047` and is not a
  deployable score.

This closes the proposed direct `yolo_f`/`class_f` cross-attention route at the
readiness gate: the paired views do not provide enough complementary class-1
decisions to justify a new trainable fusion branch.

## Decision

Reject this exact fixed LDR-KL stage-2 recipe. Do not continue it to a longer
probe and do not sweep nearby margin, temperature, learning rate, sampler, or
teacher settings. Keep the default-off implementation for reproducible
ablation. Evaluate the paper's mathematically distinct adaptive per-sample
variant only if a leakage-safe uncertainty-readiness audit passes first.

## Contents

- `source_smoke`: configuration, history, metrics, confusion plots, and trace
  summary; no checkpoint.
- `xai`: complete aggregate XAI tables and five visually reviewed cases.
- `paired_view_precheck`: full paired-view complementarity summary and class-1
  FN/FP case tables.

No raw dataset file, checkpoint, or test output is retained in this package.
