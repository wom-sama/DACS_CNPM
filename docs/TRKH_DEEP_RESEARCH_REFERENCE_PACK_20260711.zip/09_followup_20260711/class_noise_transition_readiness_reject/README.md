# Class-noise transition readiness

This no-test diagnostic treats independent expert predictions only as latent-clean proxies and checks whether their implied forward transition matrices agree across experts and train-OOF/validation. Failure means the matrix is not identifiable enough to train with.
