# CoAtNet-Nano Stage-Wise Hybrid Rejection Evidence

## Scope

- Architecture: `timm coatnet_nano_rw_224`, 14,630,809 parameters, initialized
  from scratch.
- Mechanism: stage-wise MBConv blocks followed by relative-attention blocks.
- Data: immutable `yolo_f`, object-crop classification path, image size 224.
- Training: strict balanced sampler, LDAM-focal, EMA 0.995,
  teacher-focus-binary 0.015, and 120 train batches per epoch.
- Scheduler: cosine horizon 15. Stateful resumes preserved optimizer,
  scheduler, scaler, and EMA through epoch 15.
- Leakage guard: full validation only; final test was never opened.

## Result

| Checkpoint | Val macro F1 | Class-1 P | Class-1 R | Class-1 F1 |
|---|---:|---:|---:|---:|
| Epoch 5 | 0.830315 | 0.436782 | 0.754967 | 0.553398 |
| Epoch 10 | 0.855301 | 0.525346 | 0.754967 | 0.619565 |
| Best epoch 13, independent reload | 0.861605 | 0.535211 | 0.754967 | 0.626374 |
| Current TRKH raw keeper | 0.884675 | - | - | 0.686047 |
| Current runtime softboost keeper | 0.888675 | - | - | 0.703030 |

The trainer selected epoch 13. Epochs 14 and 15 did not improve the fair
macro-F1 selector, so the recipe was closed at its scheduler horizon rather
than extended to 30 epochs. The independent epoch-13 confusion matrix was:

```text
[[480, 55,  1,  1, 12],
 [ 21,114, 13,  0,  3],
 [  1, 22,502, 11,  8],
 [  0,  4, 67,639,  2],
 [  9, 18,  5,  3,615]]
```

Class-1 true positives remained fixed at 114 from epoch 5 through epoch 13.
Training mainly reduced class-1 false positives from 147 to 99; it did not
recover the 37 remaining false negatives.

## Audit

- Full validation support was 2,606 at every gate.
- Boundary candidates fell from 584 at epoch 5 to 460 at epoch 10 and 422 at
  epoch 13.
- On the same 12 explicit class-1-boundary cases, all three checkpoints were
  correct on 6/12. The epoch-10 continuation exchanged one correction for one
  newly broken case; epoch 13 made no net prediction improvement over epoch 10.
- Epoch-13 feature-map attention foreground/background mass was
  `0.87431/0.12569`, while Grad-CAM reported `0.08312/0.91688`.
- Mean prediction-probability drops were `-0.00149` for background blur,
  `-0.00082` for background gray, `0.00728` for center occlusion, and
  `0.10312` for object desaturation.
- The causal perturbations show strong object-color dependence and negligible
  wide-background dependence. The increasingly diffuse CoAtNet Grad-CAM is
  inconsistent with those perturbations and is not treated as proof of a
  background shortcut.

## Decision

Reject this CoAtNet-Nano recipe as a replacement for the current TRKH keeper.
It is the strongest stock scratch hybrid tested in the MobileViT/EdgeNeXt/
CoAtNet comparison, and its stage-wise MBConv-to-attention progression is
useful architecture evidence, but it remains below both keeper references and
the class-1 validation gate. Do not extend this exact recipe to 30 epochs or
sweep nearby learning-rate, loss, sampler, teacher, or normalization settings.

## Contents

- `source_5e`, `source_10e`, `source_15e`: lightweight launcher, config,
  history, curve, and metric evidence.
- `eval_5e`, `eval_10e`, `eval_15e`: independent full-validation predictions
  and metrics.
- `boundary_5e`, `boundary_10e`, `boundary_15e`: leakage-guarded boundary
  manifests.
- `xai_5e`, `xai_10e`, `xai_15e`: same-case overlays, robustness probes, and
  XAI summaries.
- `process_logs`: compact execution provenance.

The rejected checkpoints and duplicate large training renders were removed
only after this evidence package was copied, hashed, and verified.
