from pathlib import Path
from typing import Callable, Optional, Tuple

import torch
from PIL import Image
from torch.utils.data import DataLoader
from torchvision.datasets import ImageFolder
from torchvision.transforms import v2 as transforms

from model import DEFAULT_RESNET, DEFAULT_VIT, get_model_data_configs


class SquarePad:
    def __init__(self, fill: int = 0) -> None:
        self.fill = fill

    def __call__(self, image: Image.Image) -> Image.Image:
        width, height = image.size
        side = max(width, height)
        left = (side - width) // 2
        top = (side - height) // 2
        right = side - width - left
        bottom = side - height - top
        return transforms.functional.pad(
            image, [left, top, right, bottom], fill=self.fill
        )


class DualInputImageFolder(ImageFolder):
    """Apply shared geometry once, then branch-specific normalization."""

    def __init__(
        self,
        root: str,
        shared_transform: Callable,
        resnet_transform: Callable,
        vit_transform: Callable,
    ) -> None:
        super().__init__(root=root, transform=None)
        self.shared_transform = shared_transform
        self.resnet_transform = resnet_transform
        self.vit_transform = vit_transform

    def __getitem__(self, index: int):
        path, target = self.samples[index]
        image = self.loader(path)
        image = self.shared_transform(image)
        return self.resnet_transform(image), self.vit_transform(image), target


def build_transforms(
    train: bool,
    image_size: int = 224,
    resnet_name: str = DEFAULT_RESNET,
    vit_name: str = DEFAULT_VIT,
) -> Tuple[Callable, Callable, Callable]:
    resnet_cfg, vit_cfg = get_model_data_configs(resnet_name, vit_name)

    shared_ops = [SquarePad(), transforms.Resize((image_size, image_size), antialias=True)]
    if train:
        shared_ops.extend(
            [
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomApply(
                    [
                        transforms.RandomAffine(
                            degrees=6,
                            translate=(0.03, 0.03),
                            scale=(0.95, 1.05),
                        )
                    ],
                    p=0.4,
                ),
                transforms.RandomApply(
                    [
                        transforms.ColorJitter(
                            brightness=0.08,
                            contrast=0.08,
                            saturation=0.05,
                            hue=0.01,
                        )
                    ],
                    p=0.25,
                ),
            ]
        )

    shared_transform = transforms.Compose(shared_ops)
    to_float = [
        transforms.ToImage(),
        transforms.ToDtype(torch.float32, scale=True),
    ]
    resnet_transform = transforms.Compose(
        to_float
        + [
            transforms.Normalize(
                mean=resnet_cfg["mean"],
                std=resnet_cfg["std"],
            )
        ]
    )
    vit_transform = transforms.Compose(
        to_float
        + [
            transforms.Normalize(
                mean=vit_cfg["mean"],
                std=vit_cfg["std"],
            )
        ]
    )
    return shared_transform, resnet_transform, vit_transform


def build_dataset(
    data_root: str,
    split: str,
    train: bool,
    image_size: int = 224,
    resnet_name: str = DEFAULT_RESNET,
    vit_name: str = DEFAULT_VIT,
) -> DualInputImageFolder:
    root = Path(data_root) / split
    if not root.is_dir():
        raise FileNotFoundError(f"Missing ImageFolder split: {root}")
    shared, resnet_transform, vit_transform = build_transforms(
        train=train,
        image_size=image_size,
        resnet_name=resnet_name,
        vit_name=vit_name,
    )
    return DualInputImageFolder(
        root=str(root),
        shared_transform=shared,
        resnet_transform=resnet_transform,
        vit_transform=vit_transform,
    )


def build_loader(
    dataset: DualInputImageFolder,
    batch_size: int,
    workers: int,
    train: bool,
    sampler: Optional[torch.utils.data.Sampler] = None,
    persistent_workers: bool = False,
    prefetch_factor: int = 2,
) -> DataLoader:
    kwargs = {
        "batch_size": batch_size,
        "shuffle": train and sampler is None,
        "sampler": sampler,
        "num_workers": workers,
        "pin_memory": torch.cuda.is_available(),
        "persistent_workers": bool(persistent_workers and workers > 0),
        "drop_last": train and len(dataset) >= batch_size,
    }
    if workers > 0:
        kwargs["prefetch_factor"] = int(prefetch_factor)
    return DataLoader(dataset, **kwargs)
