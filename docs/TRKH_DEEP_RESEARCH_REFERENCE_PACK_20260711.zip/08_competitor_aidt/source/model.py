from typing import Dict, Tuple

import timm
import torch
from torch import nn


DEFAULT_RESNET = "resnet50.a1_in1k"
DEFAULT_VIT = "vit_base_patch16_224.augreg2_in21k_ft_in1k"


class ResNet50ViTEnsemble(nn.Module):
    """Feature-level ResNet-50 + ViT-B/16 ensemble from the reference diagram."""

    def __init__(
        self,
        num_classes: int,
        pretrained: bool = True,
        resnet_name: str = DEFAULT_RESNET,
        vit_name: str = DEFAULT_VIT,
    ) -> None:
        super().__init__()
        self.resnet_name = resnet_name
        self.vit_name = vit_name

        self.resnet = timm.create_model(
            resnet_name,
            pretrained=pretrained,
            num_classes=0,
            global_pool="avg",
        )
        self.vit = timm.create_model(
            vit_name,
            pretrained=pretrained,
            num_classes=0,
        )

        resnet_dim = int(self.resnet.num_features)
        vit_dim = int(self.vit.num_features)
        fused_dim = resnet_dim + vit_dim
        if (resnet_dim, vit_dim, fused_dim) != (2048, 768, 2816):
            raise ValueError(
                "The selected backbones do not match the reference architecture: "
                f"got {resnet_dim} + {vit_dim} = {fused_dim}, expected 2048 + 768 = 2816."
            )

        self.classifier = nn.Sequential(
            nn.Linear(fused_dim, 1024),
            nn.BatchNorm1d(1024),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(1024, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.2),
            nn.Linear(512, num_classes),
        )

    def forward(
        self, resnet_images: torch.Tensor, vit_images: torch.Tensor
    ) -> torch.Tensor:
        resnet_features = self.resnet(resnet_images)
        vit_features = self.vit(vit_images)
        combined_features = torch.cat((resnet_features, vit_features), dim=1)
        return self.classifier(combined_features)

    def feature_dimensions(self) -> Dict[str, int]:
        return {
            "resnet": int(self.resnet.num_features),
            "vit": int(self.vit.num_features),
            "combined": int(self.resnet.num_features + self.vit.num_features),
        }


def get_model_data_configs(
    resnet_name: str = DEFAULT_RESNET,
    vit_name: str = DEFAULT_VIT,
) -> Tuple[dict, dict]:
    resnet = timm.create_model(resnet_name, pretrained=False, num_classes=0)
    vit = timm.create_model(vit_name, pretrained=False, num_classes=0)
    return (
        timm.data.resolve_model_data_config(resnet),
        timm.data.resolve_model_data_config(vit),
    )
