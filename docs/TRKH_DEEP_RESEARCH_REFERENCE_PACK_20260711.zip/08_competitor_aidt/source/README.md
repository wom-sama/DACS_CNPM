# ResNet50 + ViT-B/16 ensemble cho phân loại xoài

Project này xây dựng lại kiến trúc feature-level ensemble trong hình tham chiếu:

1. ResNet-50 tạo vector đặc trưng 2048 chiều.
2. ViT-B/16 tạo CLS-token vector 768 chiều.
3. Ghép thành vector 2816 chiều.
4. Head: `2816 -> 1024 -> 512 -> num_classes`.
5. BatchNorm, ReLU và dropout lần lượt là `0.3` và `0.2`.

`num_classes` được suy ra tự động từ các thư mục lớp. Mô hình trả logits khi train;
softmax chỉ được áp dụng khi đánh giá/dự đoán vì `CrossEntropyLoss` đã bao gồm
log-softmax.

## Dữ liệu mặc định

Khuyến nghị dùng split 5 lớp đã group theo chuỗi để giảm rò rỉ giữa train/val/test:

```text
D:\DataAI\AIEx\image_baseline_experiments\data\cls_crops_grouped_seqsafe_w3
```

Cấu trúc cần có:

```text
dataset/
  train/<class_name>/*.jpg
  val/<class_name>/*.jpg
  test/<class_name>/*.jpg
```

Bộ 5 lớp có 16.149 crop. Lớp
`Xoai_Song_ChuaNhe_CoNguyCo` hiếm hơn rõ rệt, vì vậy cấu hình mặc định dùng
sqrt-inverse class weights và chọn checkpoint theo validation macro-F1.

Run TRKH 5 lớp hiện có
`mango_cls_224_cnnstem_vitreg_5cls_objectcrops_rarecrop_local_v3` dùng split
YOLO gốc, không phải split grouped ở trên. Không so sánh trực tiếp metric của hai
run nếu test set khác nhau. Phương án nghiêm ngặt hơn là huấn luyện lại cả hai
mô hình trên split grouped/sequence-safe. Nếu bắt buộc tái hiện split cũ cho một
baseline tương ứng, dùng:

```text
D:\DataAI\AIEx\image_baseline_experiments\data\cls_crops
```

Để so sánh với pipeline 4 lớp hiện tại, chỉ cần thay `--data` bằng:

```text
D:\DataAI\AIEx\image_baseline_experiments\data\cls_crops_merge01_4cls_grouped_seqsafe_w3
```

Không so sánh kết quả 4 lớp và 5 lớp trong cùng một bảng như thể đó là cùng bài toán.

## Kiểm tra kiến trúc

```powershell
cd D:\DataAI\AIDT
D:\DataAI\.venv\Scripts\python.exe smoke_test.py
```

Kết quả phải có output `[2, 5]` và feature dimensions `2048 + 768 = 2816`.

## Huấn luyện 5 lớp

```powershell
powershell -ExecutionPolicy Bypass -File D:\DataAI\AIDT\run_train_5class.ps1
```

Hoặc gọi trực tiếp:

```powershell
D:\DataAI\.venv\Scripts\python.exe D:\DataAI\AIDT\train.py `
  --data D:\DataAI\AIEx\image_baseline_experiments\data\cls_crops_grouped_seqsafe_w3 `
  --outdir D:\DataAI\AIDT\runs\resnet50_vit_b16_5class `
  --epochs 30 --batch-size 6 --grad-accum 4 --workers 4 `
  --backbone-lr 1e-5 --head-lr 3e-4 `
  --class-balance sqrt_inverse --amp
```

RTX 4060 Laptop 8 GB nên bắt đầu với batch 6. Nếu hết VRAM, giảm xuống batch 4
và tăng `--grad-accum` để giữ effective batch gần tương đương.

Checkpoint pretrained ViT có thể được tải trong lần chạy đầu. Script PowerShell
dùng chung Hugging Face/Torch cache của project baseline hiện có.

## Smoke train

Lệnh sau kiểm tra toàn bộ data loader, forward, backward, checkpoint và evaluate
nhưng không tạo ra kết quả có giá trị khoa học:

```powershell
D:\DataAI\.venv\Scripts\python.exe D:\DataAI\AIDT\train.py `
  --data D:\DataAI\AIEx\image_baseline_experiments\data\cls_crops_grouped_seqsafe_w3 `
  --outdir D:\DataAI\AIDT\runs\smoke `
  --epochs 1 --batch-size 2 --workers 0 `
  --max-train-batches 1 --max-eval-batches 1 `
  --no-pretrained --amp
```

## Dự đoán một crop xoài

```powershell
D:\DataAI\.venv\Scripts\python.exe D:\DataAI\AIDT\predict.py `
  --checkpoint D:\DataAI\AIDT\runs\resnet50_vit_b16_5class\best.pt `
  --image D:\duong_dan\crop_xoai.jpg `
  --top-k 3
```

## Kết quả

Mỗi run ghi:

- `best.pt`: checkpoint tốt nhất theo validation macro-F1.
- `config.json`: cấu hình, lớp, class weights và số tham số.
- `history.csv`: loss và metric từng epoch.
- `metrics.json`: accuracy, balanced accuracy, macro-F1 và metric từng lớp.
- `predictions.csv`: dự đoán trên test.
- `confusion_matrix.png`: ma trận nhầm lẫn.

Để so sánh công bằng với mô hình khác, phải dùng cùng split, cùng định nghĩa lớp,
cùng test set và báo ít nhất macro-F1, recall từng lớp, số tham số và thời gian
suy luận. Accuracy chỉ là metric phụ do dữ liệu 5 lớp mất cân bằng.
# Current class_f 5-class command

Use this wrapper for the current dataset `D:\DataAI\AIEx\newdataset\class_f`.

```powershell
powershell -ExecutionPolicy Bypass -File D:\DataAI\AIDT\run_train_class_f_5class.ps1 `
  -UsePretrained true `
  -Epochs 30 `
  -BatchSize 6 `
  -GradAccum 4 `
  -Workers 4
```

Use `-UsePretrained false` for a scratch ablation. Smoke test:

```powershell
powershell -ExecutionPolicy Bypass -File D:\DataAI\AIDT\run_train_class_f_5class.ps1 `
  -UsePretrained false `
  -Epochs 1 `
  -BatchSize 2 `
  -GradAccum 1 `
  -Workers 0 `
  -MaxTrainBatches 1 `
  -MaxEvalBatches 1 `
  -OutDir D:\DataAI\AIDT\runs\smoke_class_f_scratch
```
