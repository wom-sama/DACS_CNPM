$ErrorActionPreference = "Stop"

$Python = "D:\DataAI\.venv\Scripts\python.exe"
$Project = "D:\DataAI\AIDT"
$Data = "D:\DataAI\AIEx\image_baseline_experiments\data\cls_crops_grouped_seqsafe_w3"

$env:HF_HOME = "D:\DataAI\AIEx\image_baseline_experiments\.hf_cache"
$env:TORCH_HOME = "D:\DataAI\AIEx\image_baseline_experiments\.torch_cache"

Set-Location $Project
& $Python train.py `
  --data $Data `
  --outdir "$Project\runs\resnet50_vit_b16_5class" `
  --epochs 30 `
  --batch-size 6 `
  --grad-accum 4 `
  --workers 4 `
  --backbone-lr 1e-5 `
  --head-lr 3e-4 `
  --class-balance sqrt_inverse `
  --amp
