import argparse
import csv
import json
import math
import random
import time
from collections import Counter
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    precision_recall_fscore_support,
)
from torch import nn
from tqdm import tqdm

from data import build_dataset, build_loader
from model import DEFAULT_RESNET, DEFAULT_VIT, ResNet50ViTEnsemble


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train the ResNet50 + ViT-B/16 feature-fusion ensemble."
    )
    parser.add_argument("--data", required=True, help="ImageFolder root with train/val/test.")
    parser.add_argument("--outdir", default="runs/resnet50_vit_b16")
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--grad-accum", type=int, default=2)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--image-size", type=int, default=224)
    parser.add_argument("--backbone-lr", type=float, default=1e-5)
    parser.add_argument("--head-lr", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=0.05)
    parser.add_argument("--warmup-epochs", type=int, default=2)
    parser.add_argument("--patience", type=int, default=7)
    parser.add_argument("--label-smoothing", type=float, default=0.05)
    parser.add_argument(
        "--class-balance",
        choices=("none", "sqrt_inverse", "inverse"),
        default="sqrt_inverse",
    )
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--resnet", default=DEFAULT_RESNET)
    parser.add_argument("--vit", default=DEFAULT_VIT)
    parser.add_argument("--amp", action="store_true")
    parser.add_argument(
        "--amp-dtype",
        choices=("bf16", "fp16"),
        default="bf16",
        help="BF16 is more stable on RTX 30/40-series GPUs.",
    )
    pretrained_group = parser.add_mutually_exclusive_group()
    pretrained_group.add_argument(
        "--pretrained",
        dest="pretrained",
        action="store_true",
        default=True,
        help="Use pretrained ResNet/ViT backbones. This is the default.",
    )
    pretrained_group.add_argument(
        "--no-pretrained",
        dest="pretrained",
        action="store_false",
        help="Train both backbones from random initialization.",
    )
    parser.add_argument(
        "--max-train-batches",
        type=int,
        default=0,
        help="Limit batches for a smoke test; 0 uses the complete split.",
    )
    parser.add_argument(
        "--max-eval-batches",
        type=int,
        default=0,
        help="Limit val/test batches for a smoke test; 0 uses the complete split.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Build datasets/model and run one train/val/test forward pass, then exit without training.",
    )
    parser.add_argument(
        "--finalize-only",
        action="store_true",
        help="Skip training and only evaluate an existing checkpoint to produce metrics/predictions.",
    )
    parser.add_argument(
        "--checkpoint",
        default="",
        help="Checkpoint for --finalize-only. Defaults to <outdir>/best.pt.",
    )
    parser.add_argument(
        "--log-every",
        type=int,
        default=100,
        help="Print a train heartbeat every N batches; 0 disables batch heartbeat.",
    )
    parser.add_argument(
        "--eval-log-every",
        type=int,
        default=100,
        help="Print an eval heartbeat every N batches; 0 disables eval heartbeat.",
    )
    parser.add_argument(
        "--persistent-workers",
        action="store_true",
        help="Keep train DataLoader workers alive between epochs. Faster, but less conservative on Windows.",
    )
    parser.add_argument("--prefetch-factor", type=int, default=2)
    args = parser.parse_args()
    args.no_pretrained = not bool(args.pretrained)
    return args


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def calculate_class_weights(
    targets: Iterable[int],
    num_classes: int,
    mode: str,
) -> torch.Tensor:
    counts = np.bincount(np.asarray(list(targets)), minlength=num_classes).astype(np.float64)
    if np.any(counts == 0):
        raise ValueError(f"At least one training class has no samples: {counts.tolist()}")
    if mode == "none":
        weights = np.ones_like(counts)
    elif mode == "sqrt_inverse":
        weights = np.sqrt(counts.max() / counts)
    else:
        weights = counts.max() / counts
    weights /= weights.mean()
    return torch.tensor(weights, dtype=torch.float32)


def metrics_from_predictions(y_true: List[int], y_pred: List[int]) -> Dict[str, float]:
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true,
        y_pred,
        average="macro",
        zero_division=0,
    )
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "macro_precision": float(precision),
        "macro_recall": float(recall),
        "macro_f1": float(f1),
    }


def move_batch(batch, device: torch.device):
    resnet_images, vit_images, labels = batch
    return (
        resnet_images.to(device, non_blocking=True),
        vit_images.to(device, non_blocking=True),
        labels.to(device, non_blocking=True),
    )


def evaluate(
    model: nn.Module,
    loader,
    criterion: nn.Module,
    device: torch.device,
    amp: bool,
    amp_dtype: torch.dtype,
    max_batches: int = 0,
    split_name: str = "eval",
    log_every: int = 0,
) -> Tuple[float, List[int], List[int], List[List[float]], float]:
    model.eval()
    losses: List[float] = []
    y_true: List[int] = []
    y_pred: List[int] = []
    probabilities: List[List[float]] = []
    start = time.perf_counter()
    with torch.inference_mode():
        for batch_index, batch in enumerate(loader, start=1):
            resnet_images, vit_images, labels = move_batch(batch, device)
            with torch.autocast(
                device_type=device.type,
                dtype=amp_dtype,
                enabled=amp and device.type == "cuda",
            ):
                logits = model(resnet_images, vit_images)
                loss = criterion(logits, labels)
            probs = logits.softmax(dim=1)
            losses.append(float(loss.item()))
            y_true.extend(labels.cpu().tolist())
            y_pred.extend(probs.argmax(dim=1).cpu().tolist())
            probabilities.extend(probs.cpu().tolist())
            if log_every and batch_index % int(log_every) == 0:
                elapsed = time.perf_counter() - start
                print(
                    json.dumps(
                        {
                            "phase": split_name,
                            "batch": int(batch_index),
                            "samples": int(len(y_true)),
                            "elapsed_seconds": round(elapsed, 2),
                        },
                        ensure_ascii=False,
                    ),
                    flush=True,
                )
            if max_batches and batch_index >= max_batches:
                break
    elapsed = time.perf_counter() - start
    ms_per_image = elapsed * 1000.0 / max(1, len(y_true))
    return float(np.mean(losses)), y_true, y_pred, probabilities, ms_per_image


def save_confusion_matrix(
    y_true: List[int],
    y_pred: List[int],
    classes: List[str],
    path: Path,
) -> None:
    matrix = confusion_matrix(y_true, y_pred, labels=list(range(len(classes))))
    figure, axis = plt.subplots(figsize=(9, 8))
    image = axis.imshow(matrix, cmap="Blues")
    figure.colorbar(image, ax=axis)
    axis.set(
        xticks=np.arange(len(classes)),
        yticks=np.arange(len(classes)),
        xticklabels=classes,
        yticklabels=classes,
        xlabel="Predicted",
        ylabel="True",
        title="Confusion matrix",
    )
    plt.setp(axis.get_xticklabels(), rotation=35, ha="right")
    threshold = matrix.max() / 2 if matrix.size else 0
    for row in range(matrix.shape[0]):
        for col in range(matrix.shape[1]):
            axis.text(
                col,
                row,
                str(matrix[row, col]),
                ha="center",
                va="center",
                color="white" if matrix[row, col] > threshold else "black",
            )
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def write_history(path: Path, history: List[Dict[str, float]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(history[0]) if history else [])
        if history:
            writer.writeheader()
            writer.writerows(history)


def main() -> None:
    args = parse_args()
    seed_everything(args.seed)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    train_dataset = build_dataset(
        args.data, "train", True, args.image_size, args.resnet, args.vit
    )
    val_dataset = build_dataset(
        args.data, "val", False, args.image_size, args.resnet, args.vit
    )
    test_dataset = build_dataset(
        args.data, "test", False, args.image_size, args.resnet, args.vit
    )
    if train_dataset.classes != val_dataset.classes or train_dataset.classes != test_dataset.classes:
        raise ValueError("Class names/order differ between train, val, and test splits.")

    classes = train_dataset.classes
    class_counts = Counter(train_dataset.targets)
    class_weights = calculate_class_weights(
        train_dataset.targets, len(classes), args.class_balance
    )
    train_loader = build_loader(
        train_dataset,
        args.batch_size,
        args.workers,
        train=True,
        persistent_workers=args.persistent_workers,
        prefetch_factor=args.prefetch_factor,
    )
    val_loader = build_loader(
        val_dataset,
        args.batch_size,
        args.workers,
        train=False,
        persistent_workers=False,
        prefetch_factor=args.prefetch_factor,
    )
    test_loader = build_loader(
        test_dataset,
        args.batch_size,
        args.workers,
        train=False,
        persistent_workers=False,
        prefetch_factor=args.prefetch_factor,
    )

    model = ResNet50ViTEnsemble(
        num_classes=len(classes),
        pretrained=args.pretrained,
        resnet_name=args.resnet,
        vit_name=args.vit,
    ).to(device)
    criterion = nn.CrossEntropyLoss(
        weight=class_weights.to(device),
        label_smoothing=args.label_smoothing,
    )
    optimizer = torch.optim.AdamW(
        [
            {
                "params": list(model.resnet.parameters()) + list(model.vit.parameters()),
                "lr": args.backbone_lr,
            },
            {"params": model.classifier.parameters(), "lr": args.head_lr},
        ],
        weight_decay=args.weight_decay,
    )

    warmup_epochs = min(args.warmup_epochs, max(0, args.epochs - 1))
    if warmup_epochs:
        scheduler = torch.optim.lr_scheduler.SequentialLR(
            optimizer,
            schedulers=[
                torch.optim.lr_scheduler.LinearLR(
                    optimizer, start_factor=0.1, total_iters=warmup_epochs
                ),
                torch.optim.lr_scheduler.CosineAnnealingLR(
                    optimizer, T_max=max(1, args.epochs - warmup_epochs)
                ),
            ],
            milestones=[warmup_epochs],
        )
    else:
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=max(1, args.epochs)
        )

    amp_dtype = torch.bfloat16 if args.amp_dtype == "bf16" else torch.float16
    use_grad_scaler = (
        args.amp and device.type == "cuda" and amp_dtype == torch.float16
    )
    scaler = torch.amp.GradScaler("cuda", enabled=use_grad_scaler)
    run_config = {
        **vars(args),
        "device": str(device),
        "classes": classes,
        "class_counts": {classes[index]: class_counts[index] for index in range(len(classes))},
        "class_weights": class_weights.tolist(),
        "feature_dimensions": model.feature_dimensions(),
        "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
    }
    config_path = outdir / ("finalize_config.json" if args.finalize_only else "config.json")
    config_path.write_text(
        json.dumps(run_config, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(run_config, indent=2, ensure_ascii=False))

    if args.dry_run:
        print("Running dry-run forward checks.", flush=True)
        model.eval()
        with torch.inference_mode():
            train_batch = next(iter(train_loader))
            resnet_images, vit_images, labels = move_batch(train_batch, device)
            with torch.autocast(
                device_type=device.type,
                dtype=amp_dtype,
                enabled=args.amp and device.type == "cuda",
            ):
                logits = model(resnet_images, vit_images)
            val_loss, val_true, _, _, _ = evaluate(
                model,
                val_loader,
                criterion,
                device,
                args.amp,
                amp_dtype,
                max_batches=1,
                split_name="dry_val",
                log_every=0,
            )
            test_loss, test_true, _, _, _ = evaluate(
                model,
                test_loader,
                criterion,
                device,
                args.amp,
                amp_dtype,
                max_batches=1,
                split_name="dry_test",
                log_every=0,
            )
        print(
            json.dumps(
                {
                    "dry_run": True,
                    "train_batch_resnet_shape": list(resnet_images.shape),
                    "train_batch_vit_shape": list(vit_images.shape),
                    "label_shape": list(labels.shape),
                    "logits_shape": list(logits.shape),
                    "val_samples_checked": len(val_true),
                    "val_loss": val_loss,
                    "test_samples_checked": len(test_true),
                    "test_loss": test_loss,
                },
                ensure_ascii=False,
                indent=2,
            ),
            flush=True,
        )
        return

    best_macro_f1 = -math.inf
    best_epoch = 0
    epochs_without_improvement = 0
    history: List[Dict[str, float]] = []
    autocast_enabled = args.amp and device.type == "cuda"

    if args.finalize_only:
        checkpoint_path = Path(args.checkpoint) if args.checkpoint else outdir / "best.pt"
        if not checkpoint_path.is_file():
            raise FileNotFoundError(f"Missing checkpoint for --finalize-only: {checkpoint_path}")
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
        best_epoch = int(checkpoint.get("best_epoch", 0) or 0)
        best_macro_f1 = float(checkpoint.get("best_macro_f1", 0.0) or 0.0)
        print(
            json.dumps(
                {
                    "phase": "finalize_only",
                    "checkpoint": str(checkpoint_path),
                    "best_epoch": best_epoch,
                    "best_macro_f1": best_macro_f1,
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
    else:
        for epoch in range(1, args.epochs + 1):
            epoch_start = time.perf_counter()
            model.train()
            optimizer.zero_grad(set_to_none=True)
            train_losses: List[float] = []
            progress = tqdm(train_loader, desc=f"epoch {epoch}/{args.epochs}", leave=False)
            processed_batches = 0
            for batch_index, batch in enumerate(progress, start=1):
                resnet_images, vit_images, labels = move_batch(batch, device)
                with torch.autocast(
                    device_type=device.type,
                    dtype=amp_dtype,
                    enabled=autocast_enabled,
                ):
                    logits = model(resnet_images, vit_images)
                    loss = criterion(logits, labels) / args.grad_accum
                scaler.scale(loss).backward()
                processed_batches += 1
                if batch_index % args.grad_accum == 0:
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    scaler.step(optimizer)
                    scaler.update()
                    optimizer.zero_grad(set_to_none=True)
                train_losses.append(float(loss.item() * args.grad_accum))
                progress.set_postfix(loss=f"{train_losses[-1]:.4f}")
                if args.log_every and batch_index % int(args.log_every) == 0:
                    elapsed = time.perf_counter() - epoch_start
                    print(
                        json.dumps(
                            {
                                "phase": "train",
                                "epoch": int(epoch),
                                "batch": int(batch_index),
                                "loss": float(train_losses[-1]),
                                "elapsed_seconds": round(elapsed, 2),
                            },
                            ensure_ascii=False,
                        ),
                        flush=True,
                    )
                if args.max_train_batches and batch_index >= args.max_train_batches:
                    break

            if processed_batches % args.grad_accum:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad(set_to_none=True)
            scheduler.step()

            val_loss, y_true, y_pred, _, _ = evaluate(
                model,
                val_loader,
                criterion,
                device,
                args.amp,
                amp_dtype,
                args.max_eval_batches,
                split_name="val",
                log_every=args.eval_log_every,
            )
            val_metrics = metrics_from_predictions(y_true, y_pred)
            row = {
                "epoch": epoch,
                "train_loss": float(np.mean(train_losses)),
                "val_loss": val_loss,
                "epoch_seconds": float(time.perf_counter() - epoch_start),
                **{f"val_{key}": value for key, value in val_metrics.items()},
            }
            history.append(row)
            print(json.dumps(row, ensure_ascii=False), flush=True)
            write_history(outdir / "history.csv", history)

            if val_metrics["macro_f1"] > best_macro_f1:
                best_macro_f1 = val_metrics["macro_f1"]
                best_epoch = epoch
                epochs_without_improvement = 0
                torch.save(
                    {
                        "model": model.state_dict(),
                        "classes": classes,
                        "args": vars(args),
                        "best_epoch": best_epoch,
                        "best_macro_f1": best_macro_f1,
                    },
                    outdir / "best.pt",
                )
            else:
                epochs_without_improvement += 1
                if epochs_without_improvement >= args.patience:
                    print(f"Early stopping at epoch {epoch}.", flush=True)
                    break

    if not args.finalize_only:
        write_history(outdir / "history.csv", history)

    checkpoint_path = Path(args.checkpoint) if args.checkpoint else outdir / "best.pt"
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model"])
    print(
        json.dumps(
            {
                "phase": "final_test",
                "checkpoint": str(checkpoint_path),
                "best_epoch": int(checkpoint.get("best_epoch", best_epoch) or best_epoch),
            },
            ensure_ascii=False,
        ),
        flush=True,
    )
    test_loss, y_true, y_pred, probabilities, ms_per_image = evaluate(
        model,
        test_loader,
        criterion,
        device,
        args.amp,
        amp_dtype,
        args.max_eval_batches,
        split_name="test",
        log_every=args.eval_log_every,
    )
    test_metrics = metrics_from_predictions(y_true, y_pred)
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true,
        y_pred,
        labels=list(range(len(classes))),
        zero_division=0,
    )
    per_class = {
        class_name: {
            "precision": float(precision[index]),
            "recall": float(recall[index]),
            "f1": float(f1[index]),
            "support": int(support[index]),
        }
        for index, class_name in enumerate(classes)
    }

    evaluated_samples = test_dataset.samples[: len(y_true)]
    with (outdir / "predictions.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["path", "y_true", "y_pred", "true_name", "pred_name", "confidence"]
        )
        for (path, _), truth, prediction, probs in zip(
            evaluated_samples, y_true, y_pred, probabilities
        ):
            writer.writerow(
                [
                    path,
                    truth,
                    prediction,
                    classes[truth],
                    classes[prediction],
                    max(probs),
                ]
            )

    save_confusion_matrix(y_true, y_pred, classes, outdir / "confusion_matrix.png")
    summary = {
        "model": "ResNet50 + ViT-B/16 feature fusion",
        "best_epoch": int(checkpoint.get("best_epoch", best_epoch) or best_epoch),
        "best_val_macro_f1": float(checkpoint.get("best_macro_f1", best_macro_f1) or best_macro_f1),
        "test_loss": test_loss,
        "test_metrics": test_metrics,
        "per_class": per_class,
        "test_size": len(y_true),
        "inference_time_ms_per_image": ms_per_image,
        "classes": classes,
        "parameter_count": run_config["parameter_count"],
    }
    (outdir / "metrics.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False), flush=True)
    return

    for epoch in range(1, args.epochs + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        train_losses: List[float] = []
        progress = tqdm(train_loader, desc=f"epoch {epoch}/{args.epochs}", leave=False)
        processed_batches = 0
        for batch_index, batch in enumerate(progress, start=1):
            resnet_images, vit_images, labels = move_batch(batch, device)
            with torch.autocast(
                device_type=device.type,
                dtype=amp_dtype,
                enabled=autocast_enabled,
            ):
                logits = model(resnet_images, vit_images)
                loss = criterion(logits, labels) / args.grad_accum
            scaler.scale(loss).backward()
            processed_batches += 1
            if batch_index % args.grad_accum == 0:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad(set_to_none=True)
            train_losses.append(float(loss.item() * args.grad_accum))
            progress.set_postfix(loss=f"{train_losses[-1]:.4f}")
            if args.max_train_batches and batch_index >= args.max_train_batches:
                break

        if processed_batches % args.grad_accum:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad(set_to_none=True)
        scheduler.step()

        val_loss, y_true, y_pred, _, _ = evaluate(
            model,
            val_loader,
            criterion,
            device,
            args.amp,
            amp_dtype,
            args.max_eval_batches,
        )
        val_metrics = metrics_from_predictions(y_true, y_pred)
        row = {
            "epoch": epoch,
            "train_loss": float(np.mean(train_losses)),
            "val_loss": val_loss,
            **{f"val_{key}": value for key, value in val_metrics.items()},
        }
        history.append(row)
        print(json.dumps(row, ensure_ascii=False))

        if val_metrics["macro_f1"] > best_macro_f1:
            best_macro_f1 = val_metrics["macro_f1"]
            best_epoch = epoch
            epochs_without_improvement = 0
            torch.save(
                {
                    "model": model.state_dict(),
                    "classes": classes,
                    "args": vars(args),
                    "best_epoch": best_epoch,
                    "best_macro_f1": best_macro_f1,
                },
                outdir / "best.pt",
            )
        else:
            epochs_without_improvement += 1
            if epochs_without_improvement >= args.patience:
                print(f"Early stopping at epoch {epoch}.")
                break

    with (outdir / "history.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(history[0]) if history else [])
        if history:
            writer.writeheader()
            writer.writerows(history)

    checkpoint = torch.load(outdir / "best.pt", map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model"])
    test_loss, y_true, y_pred, probabilities, ms_per_image = evaluate(
        model,
        test_loader,
        criterion,
        device,
        args.amp,
        amp_dtype,
        args.max_eval_batches,
    )
    test_metrics = metrics_from_predictions(y_true, y_pred)
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true,
        y_pred,
        labels=list(range(len(classes))),
        zero_division=0,
    )
    per_class = {
        class_name: {
            "precision": float(precision[index]),
            "recall": float(recall[index]),
            "f1": float(f1[index]),
            "support": int(support[index]),
        }
        for index, class_name in enumerate(classes)
    }

    evaluated_samples = test_dataset.samples[: len(y_true)]
    with (outdir / "predictions.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            ["path", "y_true", "y_pred", "true_name", "pred_name", "confidence"]
        )
        for (path, _), truth, prediction, probs in zip(
            evaluated_samples, y_true, y_pred, probabilities
        ):
            writer.writerow(
                [
                    path,
                    truth,
                    prediction,
                    classes[truth],
                    classes[prediction],
                    max(probs),
                ]
            )

    save_confusion_matrix(y_true, y_pred, classes, outdir / "confusion_matrix.png")
    summary = {
        "model": "ResNet50 + ViT-B/16 feature fusion",
        "best_epoch": best_epoch,
        "best_val_macro_f1": best_macro_f1,
        "test_loss": test_loss,
        "test_metrics": test_metrics,
        "per_class": per_class,
        "test_size": len(y_true),
        "inference_time_ms_per_image": ms_per_image,
        "classes": classes,
        "parameter_count": run_config["parameter_count"],
    }
    (outdir / "metrics.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
