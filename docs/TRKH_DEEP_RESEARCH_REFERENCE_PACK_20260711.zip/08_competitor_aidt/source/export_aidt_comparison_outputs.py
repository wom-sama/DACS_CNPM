#!/usr/bin/env python
# export_aidt_comparison_outputs.py
# Evaluate an AIDT ResNet50+ViT-B/16 fusion checkpoint and export:
# metrics.json, metrics_detailed.json, predictions.csv, predictions_detailed.csv

import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import yaml
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms

try:
    import timm
except Exception as e:
    raise RuntimeError("Missing package: timm. Install with: pip install timm") from e

try:
    from sklearn.metrics import precision_recall_fscore_support, confusion_matrix, accuracy_score
except Exception as e:
    raise RuntimeError("Missing package: scikit-learn. Install with: pip install scikit-learn") from e


IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}


class ResNetViTFusion(nn.Module):
    def __init__(self, resnet_name: str, vit_name: str, num_classes: int):
        super().__init__()
        self.resnet = timm.create_model(resnet_name, pretrained=False, num_classes=0, global_pool="avg")
        self.vit = timm.create_model(vit_name, pretrained=False, num_classes=0)

        resnet_dim = getattr(self.resnet, "num_features", 2048)
        vit_dim = getattr(self.vit, "num_features", 768)

        # This matches the uploaded checkpoint keys:
        # classifier.0.*, classifier.1.*, classifier.4.*, classifier.5.*, classifier.8.*
        self.classifier = nn.Sequential(
            nn.Linear(resnet_dim + vit_dim, 1024),
            nn.BatchNorm1d(1024),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(1024, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(512, num_classes),
        )

    def forward(self, x):
        a = self.resnet(x)
        b = self.vit(x)
        z = torch.cat([a, b], dim=1)
        return self.classifier(z)


class FolderDataset(Dataset):
    def __init__(self, root: Path, classes, image_size: int):
        self.root = Path(root)
        self.classes = list(classes)
        self.class_to_idx = {c: i for i, c in enumerate(self.classes)}
        self.samples = []

        for class_name in self.classes:
            class_dir = self.root / class_name
            if not class_dir.exists():
                continue
            for p in class_dir.rglob("*"):
                if p.is_file() and p.suffix.lower() in IMG_EXTS:
                    self.samples.append((p, self.class_to_idx[class_name], class_name))

        if not self.samples:
            raise RuntimeError(f"No images found under: {self.root}")

        self.tf = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
        ])

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        p, y, name = self.samples[idx]
        img = Image.open(p).convert("RGB")
        return self.tf(img), y, str(p), name


def resolve_split_dir(data_yaml: str, split: str) -> Path:
    data_yaml = Path(data_yaml)
    with open(data_yaml, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    base = data.get("path", data_yaml.parent)
    base = Path(base)
    if not base.is_absolute():
        base = (data_yaml.parent / base).resolve()

    split_value = data.get(split, split)
    split_path = Path(split_value)
    if not split_path.is_absolute():
        split_path = base / split_path

    return split_path


def to_float(x):
    return float(x) if x is not None else None


def bootstrap_ci(y_true, y_pred, metric_fn, n=1000, seed=42):
    rng = np.random.default_rng(seed)
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    vals = []
    m = len(y_true)
    for _ in range(n):
        idx = rng.integers(0, m, size=m)
        vals.append(metric_fn(y_true[idx], y_pred[idx]))
    return [float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--split", default="test", choices=["train", "val", "test"])
    ap.add_argument("--batch-size", type=int, default=64)
    ap.add_argument("--num-workers", type=int, default=4)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--paper-name", default="ResNet50-ViT-B16-5Class")
    ap.add_argument("--family", default="BKH")
    ap.add_argument("--backend", default="aidt")
    ap.add_argument("--model-name", default="resnet50_vit_b16")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--image-size", type=int, default=None)
    args = ap.parse_args()

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    ckpt = torch.load(args.checkpoint, map_location="cpu")
    classes = ckpt.get("classes")
    if not classes:
        raise RuntimeError("Checkpoint has no `classes` list.")

    ckpt_args = ckpt.get("args", {})
    image_size = args.image_size or int(ckpt_args.get("image_size", 224))
    resnet_name = ckpt_args.get("resnet", "resnet50.a1_in1k")
    vit_name = ckpt_args.get("vit", "vit_base_patch16_224.augreg2_in21k_ft_in1k")

    model = ResNetViTFusion(resnet_name, vit_name, len(classes))
    state = ckpt.get("model", ckpt.get("state_dict", ckpt))
    model.load_state_dict(state, strict=True)
    model.to(args.device)
    model.eval()

    split_dir = resolve_split_dir(args.data, args.split)
    ds = FolderDataset(split_dir, classes, image_size)
    dl = DataLoader(ds, batch_size=args.batch_size, shuffle=False,
                    num_workers=args.num_workers, pin_memory=(args.device.startswith("cuda")))

    all_true, all_pred, all_probs, all_paths, all_true_names = [], [], [], [], []
    total_loss = 0.0
    total_n = 0

    start = time.perf_counter()
    with torch.no_grad():
        for x, y, paths, true_names in dl:
            x = x.to(args.device, non_blocking=True)
            y = y.to(args.device, non_blocking=True)
            logits = model(x)
            loss = F.cross_entropy(logits, y, reduction="sum")
            probs = torch.softmax(logits, dim=1)
            pred = probs.argmax(dim=1)

            total_loss += float(loss.item())
            total_n += int(y.numel())

            all_true.extend(y.cpu().numpy().tolist())
            all_pred.extend(pred.cpu().numpy().tolist())
            all_probs.append(probs.cpu().numpy())
            all_paths.extend(list(paths))
            all_true_names.extend(list(true_names))

    elapsed = time.perf_counter() - start
    probs = np.concatenate(all_probs, axis=0)
    y_true = np.asarray(all_true)
    y_pred = np.asarray(all_pred)
    conf = probs.max(axis=1)

    labels = list(range(len(classes)))
    acc = float(accuracy_score(y_true, y_pred))
    macro_p, macro_r, macro_f1, _ = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, average="macro", zero_division=0
    )
    weighted_f1 = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, average="weighted", zero_division=0
    )[2]
    per_p, per_r, per_f1, support = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, average=None, zero_division=0
    )
    cm = confusion_matrix(y_true, y_pred, labels=labels)

    test_loss = total_loss / max(total_n, 1)
    params = int(sum(p.numel() for p in model.parameters()))
    ms_per_image = float(elapsed * 1000.0 / max(total_n, 1))

    # predictions.csv
    pred_rows = []
    for pth, yt, yp in zip(all_paths, y_true, y_pred):
        pred_rows.append({
            "path": pth,
            "y_true": int(yt),
            "y_pred": int(yp),
            "true_name": classes[int(yt)],
            "pred_name": classes[int(yp)],
        })
    pd.DataFrame(pred_rows).to_csv(out / "predictions.csv", index=False, encoding="utf-8-sig")

    # predictions_detailed.csv
    detailed_rows = []
    topk = min(5, len(classes))
    order = np.argsort(-probs, axis=1)[:, :topk]
    for i, (pth, yt, yp) in enumerate(zip(all_paths, y_true, y_pred)):
        row = {
            "sample_index": i,
            "image_path": pth,
            "target_index": int(yt),
            "target_name": classes[int(yt)],
            "prediction_index": int(yp),
            "prediction_name": classes[int(yp)],
            "confidence": float(conf[i]),
            "correct": int(yt == yp),
        }
        for k in range(topk):
            cls_i = int(order[i, k])
            row[f"top{k+1}_index"] = cls_i
            row[f"top{k+1}_name"] = classes[cls_i]
            row[f"top{k+1}_probability"] = float(probs[i, cls_i])
        for c, cname in enumerate(classes):
            row[f"prob_{c}_{cname}"] = float(probs[i, c])
        detailed_rows.append(row)
    pd.DataFrame(detailed_rows).to_csv(out / "predictions_detailed.csv", index=False, encoding="utf-8-sig")

    metrics = {
        "paper_name": args.paper_name,
        "family": args.family,
        "backend": args.backend,
        "model": args.model_name,
        "pretrained": not bool(ckpt_args.get("no_pretrained", False)),
        "test_size": int(total_n),
        "test_loss": float(test_loss),
        "metrics": {
            "accuracy": float(acc),
            "macro_precision": float(macro_p),
            "macro_recall": float(macro_r),
            "macro_f1": float(macro_f1),
        },
        "ci95": {
            "accuracy": bootstrap_ci(y_true, y_pred, lambda a, b: accuracy_score(a, b)),
            "macro_precision": bootstrap_ci(y_true, y_pred, lambda a, b: precision_recall_fscore_support(a, b, labels=labels, average="macro", zero_division=0)[0]),
            "macro_recall": bootstrap_ci(y_true, y_pred, lambda a, b: precision_recall_fscore_support(a, b, labels=labels, average="macro", zero_division=0)[1]),
            "macro_f1": bootstrap_ci(y_true, y_pred, lambda a, b: precision_recall_fscore_support(a, b, labels=labels, average="macro", zero_division=0)[2]),
        },
        "params": params,
        "inference_time_ms_per_image": ms_per_image,
        "best_epoch": ckpt.get("best_epoch"),
        "classes": classes,
    }

    per_class = []
    for c, cname in enumerate(classes):
        per_class.append({
            "class_index": c,
            "class_name": cname,
            "support": int(support[c]),
            "precision": float(per_p[c]),
            "recall": float(per_r[c]),
            "f1": float(per_f1[c]),
        })

    # Basic confidence curves with abstention below threshold.
    thresholds = np.linspace(0.0, 1.0, 101)
    curve_macro_p, curve_macro_r, curve_macro_f1 = [], [], []
    curve_per_class = [
        {"class_index": c, "class_name": cname, "precision": [], "recall": [], "f1": []}
        for c, cname in enumerate(classes)
    ]

    for t in thresholds:
        masked_pred = y_pred.copy()
        masked_pred[conf < t] = -1
        pp, rr, ff = [], [], []
        for c in labels:
            tp = int(((masked_pred == c) & (y_true == c)).sum())
            fp = int(((masked_pred == c) & (y_true != c)).sum())
            fn = int(((masked_pred != c) & (y_true == c)).sum())
            p = tp / (tp + fp) if (tp + fp) else 0.0
            r = tp / (tp + fn) if (tp + fn) else 0.0
            f = (2 * p * r / (p + r)) if (p + r) else 0.0
            pp.append(p); rr.append(r); ff.append(f)
            curve_per_class[c]["precision"].append(float(p))
            curve_per_class[c]["recall"].append(float(r))
            curve_per_class[c]["f1"].append(float(f))
        curve_macro_p.append(float(np.mean(pp)))
        curve_macro_r.append(float(np.mean(rr)))
        curve_macro_f1.append(float(np.mean(ff)))

    for c in labels:
        arr = curve_per_class[c]["f1"]
        best_idx = int(np.argmax(arr))
        curve_per_class[c]["best_f1"] = float(arr[best_idx])
        curve_per_class[c]["best_confidence"] = float(thresholds[best_idx])

    metrics_detailed = {
        "accuracy": float(acc),
        "macro_precision": float(macro_p),
        "macro_recall": float(macro_r),
        "macro_f1": float(macro_f1),
        "weighted_f1": float(weighted_f1),
        "per_class": per_class,
        "confusion_matrix": cm.tolist(),
        "confidence_curves": {
            "thresholds": [float(x) for x in thresholds],
            "macro": {
                "precision": curve_macro_p,
                "recall": curve_macro_r,
                "f1": curve_macro_f1,
            },
            "per_class": curve_per_class,
        },
        "loss": float(test_loss),
        "loss_components": {"cross_entropy": float(test_loss)},
        "tta_enabled": False,
        "tta_brightness_delta": None,
        "calibrated": False,
        "artifact_stats": {
            "num_predictions": int(total_n),
            "num_classes": int(len(classes)),
        },
        "timing": {
            "elapsed_seconds": float(elapsed),
            "inference_time_ms_per_image": ms_per_image,
        },
    }

    with open(out / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)
    with open(out / "metrics_detailed.json", "w", encoding="utf-8") as f:
        json.dump(metrics_detailed, f, ensure_ascii=False, indent=2)

    print(f"Done. Wrote outputs to: {out}")
    print(json.dumps(metrics["metrics"], indent=2))


if __name__ == "__main__":
    main()
