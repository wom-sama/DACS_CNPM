param(
  [string]$UsePretrained = "true",
  [int]$Epochs = 30,
  [int]$BatchSize = 6,
  [int]$GradAccum = 4,
  [int]$Workers = 4,
  [int]$ImageSize = 224,
  [int]$MaxTrainBatches = 0,
  [int]$MaxEvalBatches = 0,
  [string]$OutDir = ""
)

$ErrorActionPreference = "Stop"

$Python = "D:\DataAI\.venv\Scripts\python.exe"
$Project = "D:\DataAI\AIDT"
$Data = "D:\DataAI\AIEx\newdataset\class_f"

function Convert-BooleanFlag {
  param([string]$Value)
  $normalized = $Value.Trim().ToLowerInvariant()
  if ($normalized -in @("true", "1", "yes", "y", "on")) {
    return $true
  }
  if ($normalized -in @("false", "0", "no", "n", "off")) {
    return $false
  }
  throw "Invalid boolean value for -UsePretrained: '$Value'. Use true or false."
}

$env:HF_HOME = "D:\DataAI\AIEx\image_baseline_experiments\.hf_cache"
$env:TORCH_HOME = "D:\DataAI\AIEx\image_baseline_experiments\.torch_cache"

$UsePretrainedFlag = Convert-BooleanFlag $UsePretrained
$pretrainedSuffix = if ($UsePretrainedFlag) { "pretrained" } else { "scratch" }
if (-not $OutDir) {
  $OutDir = "$Project\runs\resnet50_vit_b16_class_f_5class_$pretrainedSuffix"
}

$arguments = @(
  "train.py",
  "--data", $Data,
  "--outdir", $OutDir,
  "--epochs", "$Epochs",
  "--batch-size", "$BatchSize",
  "--grad-accum", "$GradAccum",
  "--workers", "$Workers",
  "--image-size", "$ImageSize",
  "--backbone-lr", "1e-5",
  "--head-lr", "3e-4",
  "--class-balance", "sqrt_inverse",
  "--amp",
  "--amp-dtype", "bf16"
)

if ($UsePretrainedFlag) {
  $arguments += "--pretrained"
} else {
  $arguments += "--no-pretrained"
}

if ($MaxTrainBatches -gt 0) {
  $arguments += @("--max-train-batches", "$MaxTrainBatches")
}
if ($MaxEvalBatches -gt 0) {
  $arguments += @("--max-eval-batches", "$MaxEvalBatches")
}

Write-Host "Data: $Data"
Write-Host "Output: $OutDir"
Write-Host "Pretrained: $UsePretrainedFlag"
Write-Host "Epochs: $Epochs"

Set-Location $Project
& $Python @arguments
